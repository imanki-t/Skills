# Zero-Downtime Schema Migrations, Security & Governance

## Overview

Managing production databases at scale requires executing schema changes without causing application downtime, securing sensitive data (PII), and optimizing infrastructure costs.

---

## 1. Zero-Downtime Schema Migration Pattern

Directly executing `ALTER TABLE` DDL queries on large production tables can lock tables for hours, cause query timeouts, and break running applications. Big tech organizations enforce a multi-phase, backward-compatible migration strategy:

```
[Phase 1: Additive DDL] -> [Phase 2: Dual Write Code] -> [Phase 3: Async Backfill] -> [Phase 4: Read Switch] -> [Phase 5: Cleanup]
```

### The 5-Phase Migration Steps
1. **Phase 1: Additive DDL**: Add new columns or tables as nullable or with default values. Existing application code ignores the new column.
2. **Phase 2: Dual Writing**: Deploy application code that writes new/updated records to **both** the old column and the new column, but continues reading from the old column.
3. **Phase 3: Asynchronous Backfill**: Run a background batch worker to populate the new column for historical rows created prior to Phase 2.
4. **Phase 4: Read Switch**: Deploy application code to read from the new column. Monitor error rates and query latencies.
5. **Phase 5: Deprecation & Cleanup**: After verifying stability, remove dual-write logic and drop the old column/table in a final non-blocking DDL operation.

### CI/CD DDL Guardrails
Static analysis tools (e.g., gh-ost, bytebase, sqldef) run in CI to block unsafe DDL statements:
- Block `ALTER TABLE ADD COLUMN` with non-null constraints lacking default values.
- Block `DROP TABLE` or `DROP COLUMN` without prior deprecation telemetry verification.
- Block unindexed foreign key additions or operations requiring full table rewrites.

---

## 2. Security & Compliance

### Encryption
- **Encryption in Transit**: Enforce TLS 1.3 / mTLS for all client-to-database and node-to-node inter-cluster communication.
- **Encryption at Rest**: Encrypt storage volumes, WAL logs, and snapshots using KMS with automated key rotation.
- **Field-Level / Envelope Encryption**: Encrypt sensitive Personally Identifiable Information (PII) before it is written to storage using application-level keys.

### Access Control & Governance
- **Least Privilege (RBAC / ABAC)**: Applications use dedicated service accounts restricted to specific tables and operations. Developers never have direct write access to production databases.
- **Audit Logging**: Immutable logging of all DDL, administrative access, and sensitive data queries.
- **Row-Level & Column-Level Security**: Masking sensitive fields (e.g., social security numbers or credit cards) based on caller identity.

---

## 3. Storage Tiering & Cost Optimization

As data volume grows into petabytes, storing all data on high-performance local NVMe storage becomes cost-prohibitive.

- **Hot Storage (NVMe/SSD)**: Recent, heavily accessed operational data (e.g., last 30-90 days).
- **Warm Storage (Standard SSD/HDD)**: Older, less frequently accessed transaction history.
- **Cold / Object Storage (GCS/S3/Coldline)**: Historical archives, immutable logs, and compressed snapshots tiered automatically to low-cost object stores.
