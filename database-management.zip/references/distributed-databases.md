# Distributed Databases: Architecture, Sharding & Consensus

## Overview

In enterprise environments, database systems must scale horizontally across hundreds or thousands of nodes spanning multiple physical datacenters. This document details the architectural concepts behind distributed database systems like Google Spanner, Google Bigtable, Amazon DynamoDB, and CockroachDB.

---

## 1. Database Archetypes at Scale

### Distributed Relational / NewSQL (e.g., Google Spanner, CockroachDB, YugabyteDB)
- **Characteristics**: Combines traditional ACID transactional guarantees and SQL querying with horizontal scalability and global replication.
- **Use Cases**: Financial transactions, billing, inventory, user authentication, core user metadata.
- **Key Concepts**: Synchronous replication via Paxos/Raft consensus groups, global hardware time synchronization (TrueTime), distributed 2-Phase Commit (2PC) for cross-shard transactions.

### Wide-Column / NoSQL (e.g., Google Bigtable, Apache Cassandra, Amazon DynamoDB)
- **Characteristics**: Optimized for massive scale, ultra-high write throughput, and single-digit millisecond key lookups. Sacrifices complex JOINs and arbitrary SQL queries for predictable latency.
- **Use Cases**: Time-series metrics, clickstream logs, search indexing, social media feeds, IoT telemetry.
- **Key Concepts**: LSM-tree (Log-Structured Merge-tree) storage engines, SSTables, Bloom filters, hash/range partitioning.

### Distributed OLAP / Warehouses (e.g., Google BigQuery, Amazon Redshift, Snowflake)
- **Characteristics**: Columnar storage format optimized for scanning large datasets and executing aggregate analytical queries across petabytes of data.
- **Use Cases**: Business intelligence, machine learning data pipelines, historical analytics.
- **Key Concepts**: Columnar storage (e.g., Capacitor/Parquet), decoupled compute and storage, vectorized query execution engines.

---

## 2. Horizontal Sharding and Data Partitioning

Sharding is the process of splitting a large dataset into smaller, independent chunks (shards or tablets) distributed across multiple machines.

### Sharding Strategies
1. **Range-Based Sharding**:
   - Data is ordered and partitioned into contiguous key ranges (e.g., `[A-C]`, `[D-F]`).
   - *Advantage*: Highly efficient for range queries.
   - *Risk*: Subject to **hotspotting** if sequential or monotonically increasing keys (e.g., timestamps or auto-increment IDs) are used.
2. **Hash-Based / Consistent Hashing**:
   - Primary key is hashed to determine shard placement evenly across nodes.
   - *Advantage*: Prevents hotspots by distributing writes uniformly across nodes.
   - *Trade-off*: Range scans require querying all shards (scatter-gather).

### Anti-Hotspotting Design Principles
- **Hash Prefixes**: Prepend a hash or bucket ID to sequential keys (e.g., `Hash(userID) + timestamp`).
- **Dynamic Resharding**: Automated monitoring systems split large or heavily accessed shards automatically when size or QPS exceeds thresholds.

---

## 3. Distributed Consensus Protocols (Paxos & Raft)

Distributed databases use consensus algorithms to ensure that multiple replicas agree on the state of the data, even in the presence of node crashes or network partitions.

### Consensus Groups per Shard
- Rather than running a single consensus cluster for the entire database, systems like Spanner divide data into thousands of tablets, where each tablet is managed by a separate **Paxos or Raft group** (typically 3 or 5 replicas).
- A write is acknowledged as committed as soon as a majority (quorum) of replicas in the consensus group successfully record the log entry.

### Leader Election and Failover
- Each consensus group elects a **Leader**.
- Reads and writes are directed through the Leader node.
- If a Leader fails, the remaining nodes hold an election and choose a new Leader in seconds, achieving zero data loss.

---

## 4. Time Synchronization & TrueTime (Google Spanner)

Achieving strict serializability in a globally distributed database traditionally required expensive lock coordination across continents. Google solved this using **TrueTime**:

- **Hardware-Backed Time**: Google datacenters are equipped with dedicated GPS receivers and atomic clocks.
- **Bounded Uncertainty**: The TrueTime API returns a time interval `[t.earliest, t.latest]` where the true time is guaranteed to lie within an uncertainty window epsilon (typically < 1-7 ms).
- **Commit Wait Protocol**: When committing a transaction at timestamp T, Spanner waits until T < TrueTime().earliest before releasing locks, guaranteeing that future transactions receive a strictly higher timestamp. This allows lock-free snapshot reads across the entire global database.
