---
name: database-management
description: Guidance on how databases are managed at enterprise scale in companies like Google, Meta, Amazon, and Microsoft. Covers distributed database architectures (Spanner, Bigtable, DynamoDB), Database Reliability Engineering (DBRE), sharding and consensus (Paxos/Raft), zero-downtime schema migrations, security, and data governance. Use when the user asks about database management, distributed databases, DBRE/SRE practices for data, database scaling, sharding, or enterprise data architecture.
---
# Enterprise Database Management

## Philosophy

Database management at large tech companies (Google, Meta, Amazon, Microsoft) is built on three core tenets: **automation, high availability, and horizontal scalability**. 

At scale, hardware failures are statistical certainty, manual database administration is unviable, and no single machine can hold or serve all traffic. Production database management transforms databases from monolithic, manually managed servers into automated, self-healing, distributed systems managed via code (Database Reliability Engineering).

## How to Use This Skill

- **Designing Data Architecture**: Select the appropriate database archetype (Distributed SQL vs NoSQL vs Data Warehouse) based on consistency and latency requirements.
- **Scaling & Operations**: Apply sharding, consensus-based replication, and DBRE practices.
- **Executing Changes**: Follow zero-downtime schema migration patterns for safe production DDL changes.
- **Deep Dives**: Consult the files in `references/` for detailed architectural breakdowns, DBRE practices, and migration guidelines.

## The Six Pillars of Enterprise Database Management

### 1. Polyglot Persistence & Database Selection
Big tech companies do not attempt to force all workloads into a single database engine. Instead, they select purpose-built storage engines based on the specific access patterns:
- **Globally Distributed Relational (NewSQL)**: For mission-critical transactional data requiring strong consistency and ACID guarantees (e.g., Google Spanner, CockroachDB, Amazon Aurora).
- **High-Throughput Key-Value / Wide-Column**: For ultra-high write throughput, low-latency key lookup, and massive time-series or analytical logs (e.g., Google Bigtable, Amazon DynamoDB, Apache Cassandra).
- **Analytical Warehousing & OLAP**: For complex multi-terabyte/petabyte analytical queries and business intelligence (e.g., Google BigQuery, Amazon Redshift, Snowflake).
- **Cache & Document Stores**: For fast transient caching and semi-structured payloads (e.g., Redis, Memcached, MongoDB).
-> See `references/distributed-databases.md`

### 2. Horizontal Sharding & Consensus Replication
Scaling beyond a single server requires distributing data across thousands of nodes while preserving reliability.
- **Automatic Sharding**: Partitioning data ranges dynamically across servers based on primary key ranges or hash partitioning.
- **Consensus-Based Sync Replication**: Using Paxos or Raft consensus groups per shard to achieve strong consistency across geographically diverse datacenters.
- **Global Time Synchronization**: Leveraging synchronized physical hardware clocks (e.g., Google TrueTime atomic clocks and GPS) to enable lock-free distributed read transactions and external consistency.
-> See `references/distributed-databases.md`

### 3. Database Reliability Engineering (DBRE)
DBRE applies Site Reliability Engineering principles to database infrastructure.
- **Service Level Objectives (SLOs)**: Defining explicit SLIs and SLOs for read/write availability (e.g., 99.999%), p99 latency, and durability.
- **Automated Self-Healing**: Automatically detecting hardware or node failures, promoting Paxos/Raft leaders, and re-sharding data without human intervention.
- **Eliminating Toil**: Automating provisioning, backup verification, index tuning, and capacity planning.
-> See `references/dbre-and-operations.md`

### 4. Zero-Downtime Schema Migrations
Production database changes must never cause service downtime or data lockouts.
- **Additive Schema Changes**: All schema changes must be non-breaking and additive (adding optional columns, creating new tables).
- **Phased Dual-Writing**: Deploying changes across distinct phases: Write to both old and new schemas -> Asynchronously backfill historical data -> Verify parity -> Switch reads to new schema -> Deprecate old column/table.
- **Automated DDL Safety Gates**: Running static analysis on DDL scripts in CI/CD to block unsafe operations (such as table rewrites, full table locks, or unindexed foreign keys).
-> See `references/schema-migrations-and-governance.md`

### 5. Data Integrity, Backups & Disaster Recovery
Data loss is an unacceptable failure mode in enterprise infrastructure.
- **Continuous Backups & PITR**: Maintaining transaction logs and periodic snapshots to enable Point-In-Time Recovery to any specific second.
- **Automated Backup Restoration Testing**: Regularly restoring backups in isolated environments to verify backup integrity and test Recovery Time Objective (RTO) and Recovery Point Objective (RPO).
- **Chaos Engineering & GameDays**: Deliberately injecting node failures, network partitions, and datacenter outages to validate multi-region failover.
-> See `references/dbre-and-operations.md`

### 6. Security, Governance & Cost Optimization
Protecting sensitive data while managing infrastructure costs at scale.
- **Encryption at Rest & in Transit**: Encrypting all database files, WALs, and snapshots using KMS/Customer-Managed Keys, and enforcing mTLS for transport.
- **Least Privilege & Row-Level Access**: Enforcing strict IAM controls, Role-Based Access Control (RBAC), and masking PII fields.
- **Storage Tiering**: Automatically tiering data from high-performance NVMe storage to lower-cost object storage (e.g., GCS/S3) as data ages.
-> See `references/schema-migrations-and-governance.md`

## Default Behaviors (Apply When Managing Databases)

1. **Avoid Single Points of Failure**: Never deploy a database with a single primary instance without automated failover and synchronous replicas.
2. **Design Keys to Prevent Hotspots**: Never use monotonically increasing primary keys (such as sequential IDs or raw timestamps) in sharded databases; use hash-prefixed or UUID-based keys to distribute load evenly.
3. **Enforce Additive Migrations**: Always execute schema changes iteratively across code deployments rather than performing destructive schema refactors in a single step.
4. **Instrument Query Performance**: Monitor p99 query latencies, slow query logs, and index usage continuously; fix unindexed queries before they cause production outages.
5. **Test Restoration Automatically**: Never assume backups work unless automated restoration tests run and pass regularly.

## Review Rubric for Database Architecture & Changes

1. **Workload Match**: Does the chosen database engine match the workload's read/write ratio, latency requirements, and consistency needs?
2. **Scalability & Sharding**: Will the data model scale horizontally without creating hot shards?
3. **Migration Safety**: Is the DDL change backward-compatible and safe to execute under live traffic without table locks?
4. **Resilience**: How does the system handle the failure of an entire availability zone or region?
5. **Security & Compliance**: Are sensitive fields (PII) encrypted and access-controlled according to compliance standards?

## Company Snapshots

- **Google**: Built **Spanner** (globally distributed SQL database using TrueTime atomic clocks and Paxos) and **Bigtable** (sparse wide-column NoSQL store). Google uses a strict Database Reliability Engineering model where automated systems handle node failures, load balancing, and multi-region failovers continuously.
- **Amazon**: Migrated off legacy monolithic relational databases to **Amazon DynamoDB** (high-performance NoSQL with single-digit millisecond latency) and **Amazon Aurora** (decoupled compute and distributed storage engine).
- **Meta**: Operates massive MySQL clusters scaled via **Vitess** and internal sharding frameworks, alongside specialized key-value stores (RocksDB, TAO for social graph queries). Emphasizes automated schema migration pipelines and aggressive caching layers.
- **Microsoft**: Utilizes **Azure Cosmos DB** (multi-model globally distributed database with configurable consistency levels) and managed SQL instances with automated backup and geo-replication.

## Reference Files

| File | Read when... |
|---|---|
| `references/distributed-databases.md` | Designing distributed database architectures, sharding strategies, or selecting consensus protocols |
| `references/dbre-and-operations.md` | Setting up DBRE practices, monitoring SLIs/SLOs, automated failover, or disaster recovery testing |
| `references/schema-migrations-and-governance.md` | Planning zero-downtime DDL schema migrations, managing access control, PII security, or storage tiering |
