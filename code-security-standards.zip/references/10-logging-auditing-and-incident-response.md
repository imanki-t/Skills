# Logging, Auditing & Incident Response

Standards for secure structured logging, data redaction, audit trails, and fail-safe error handling.

## 1. Structured Logging Standards
Log entries must be output in machine-readable format (JSON) containing consistent operational context.
- **Required Fields**: `timestamp` (ISO-8601), `level` (INFO/WARN/ERROR), `trace_id`, `span_id`, `service_name`, `event_type`.

```json
{
  "timestamp": "2026-07-31T15:00:00.123Z",
  "level": "INFO",
  "service": "payment-service",
  "trace_id": "4bf92f3577b34da6a3ce929d0e0e4736",
  "event_type": "transaction_completed",
  "user_id": "usr_981237",
  "amount": 49.99,
  "currency": "USD"
}
```

## 2. PII / Sensitive Data Redaction
**NEVER** write passwords, credit card numbers, social security numbers, OAuth tokens, session IDs, or private keys to log files.

```python
import re

SENSITIVE_PATTERNS = [
    (re.compile(r'(?i)(password|passwd|secret|token|api_key)\s*=\s*['"][^'"]+['"]'), r'="[REDACTED]"'),
    (re.compile(r'\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}'), '[CARD REDACTED]')
]

def sanitize_log_message(msg: str) -> str:
    for pattern, replacement in SENSITIVE_PATTERNS:
        msg = pattern.sub(replacement, msg)
    return msg
```

## 3. Secure Audit Trails
Audit logs record high-privilege operations (permission changes, financial transfers, admin logins).
- **Immutability**: Write audit logs to write-once-read-many (WORM) storage or cloud buckets with object locking.
- **Tamper-Evident Logs**: Chain audit entries using cryptographic hashes (HMACs or Merkle trees).

## 4. Fail-Safe Error Handling
- **No Stack Traces to End Users**: Catch exceptions at application boundaries. Log detailed internal tracebacks securely; return generic error messages with correlation IDs to external clients.

```python
# SECURE Error Boundary
@app.errorhandler(Exception)
def handle_unexpected_error(error):
    error_id = generate_unique_error_id()
    logger.error("Unhandled exception error_id=%s: %s", error_id, str(error), exc_info=True)
    return jsonify({
        "error": "Internal Server Error",
        "message": "An unexpected error occurred. Please quote error_id when contacting support.",
        "error_id": error_id
    }), 500
```

## 5. SIEM Integration & Incident Alerts
Ingest log streams into Security Information and Event Management (SIEM) systems (e.g., Datadog, Splunk, Elastic SIEM) and establish real-time alert thresholds for:
- Multiple failed login attempts / brute-force patterns.
- Anomalous privilege escalation events.
- Spike in 403 Forbidden or 429 Too Many Requests responses.
