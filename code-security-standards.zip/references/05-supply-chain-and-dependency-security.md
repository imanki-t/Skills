# Supply Chain & Dependency Security

Frameworks for managing third-party risks, Software Bill of Materials (SBOM), dependency pinning, and build integrity.

## 1. Dependency Pinning & Lockfile Integrity
- **Pin Exact Versions**: Avoid loose ranges (`^1.2.0` or `~2.0`). Pin exact semantic versions in package manifests.
- **Lockfiles**: Commit `package-lock.json`, `poetry.lock`, `Cargo.lock`, or `go.sum` to version control.
- **Hash Verification**: Ensure installer tools verify cryptographic hashes of downloaded packages against the lockfile.

## 2. Software Bill of Materials (SBOM)
Generate and publish SBOMs for every software release to track component lineage and CVE exposure.
- **Standards**: CycloneDX (JSON/XML) or SPDX.
- **Tools**: `syft`, `cdxgen`, or `cargo-sbom`.

```bash
# Generate SBOM using Syft
syft packages dir:. -o cyclonedx-json > sbom.json
```

## 3. Supply Chain Attack Mitigations
- **Typosquatting & Dependency Confusion**:
  - Use scoped package namespaces (e.g., `@organization/package`).
  - Configure internal package registries (Artifactory, Nexus) with strict routing rules to prevent public registry fallback.
- **Script Execution Restrictions**:
  - Disable lifecycle post-install scripts during package installation where supported (`npm install --ignore-scripts`).

## 4. Automated Vulnerability Scanning
Integrate dependency vulnerability scanners into automated pipelines:
- **Trivy**: Container & filesystem scanner.
- **Snyk / Dependabot / OSV-Scanner**: Continuous dependency vulnerability monitoring.

```bash
# Scan filesystem for vulnerable dependencies
trivy fs --severity HIGH,CRITICAL .
```

## 5. SLSA Framework (Supply-chain Levels for Software Artifacts)
- **Level 1**: Build process is fully automated and produces provenance.
- **Level 2**: Build runs on hosted build service with authenticated provenance.
- **Level 3**: Build platform hardens isolation; provenance is cryptographically non-falsifiable.
