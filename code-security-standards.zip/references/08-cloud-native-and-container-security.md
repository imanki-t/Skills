# Cloud-Native & Container Security

Best practices for container hardening, Kubernetes RBAC, Infrastructure as Code (IaC) scanning, and CIS benchmarks.

## 1. Container Hardening Guidelines
- **Use Minimal Base Images**: Prefer `distroless`, Alpine, or scratch images to minimize attack surface.
- **Non-Root Execution**: Always run containerized processes as an unprivileged user (UID >= 10000).
- **Read-Only Root Filesystem**: Mount container root filesystems as read-only (`readOnlyRootFilesystem: true`).
- **Drop Linux Capabilities**: Drop `ALL` capabilities and explicitly add only necessary ones (e.g., `NET_BIND_SERVICE`).

```dockerfile
# SECURE: Dockerfile Multistage Build
FROM golang:1.22-alpine AS builder
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 GOOS=linux go build -o server .

FROM gcr.io/distroless/static-debian12:nonroot
WORKDIR /
COPY --from=builder /app/server /server
USER nonroot:nonroot
ENTRYPOINT ["/server"]
```

## 2. Kubernetes Security Hardening
- **Pod Security Standards**: Enforce `Restricted` profile via Pod Security Admission controller.
- **Network Policies**: Default deny-all ingress and egress traffic; explicitly allow necessary service flows.

```yaml
# Kubernetes NetworkPolicy: Default Deny All
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: production
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
```

## 3. Infrastructure as Code (IaC) Security Scanning
Scan Terraform, CloudFormation, and Helm charts for misconfigurations before deployment.
- **Tools**: Checkov, tfsec, KICS.

```bash
# Run Checkov on Terraform directory
checkov -d ./terraform --framework terraform
```

## 4. CIS Benchmarks Compliance
Audit infrastructure nodes, Kubernetes clusters, and cloud provider accounts against Center for Internet Security (CIS) benchmarks using tools like `kube-bench` or `prowler`.
