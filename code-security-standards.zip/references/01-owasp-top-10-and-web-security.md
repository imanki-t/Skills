# OWASP Top 10 & Web Application Security

Comprehensive guide to detecting, mitigating, and preventing core web application security threats based on the OWASP Top 10 framework.

## 1. Injection Vulnerabilities (SQLi, Command Injection, LDAPi)
### Injection Vectors
Injection occurs when untrusted data is sent to an interpreter as part of a command or query.
- **SQL Injection (SQLi)**: Manipulating database queries.
- **Command Injection**: Executing shell commands via string concatenation.
- **LDAP / XPath Injection**: Manipulating structured queries.

### Mitigations
- **Parameterized Queries**: Always use prepared statements or ORMs with parameterized bindings.
- **Command Execution Prevention**: Avoid shell invocation (`exec`, `system`, `popen`). Use safe APIs that accept argument lists without a shell wrapper (e.g., Python `subprocess.run(["cmd", "arg1"], shell=False)`).

```python
# SECURE: Parameterized SQL Query
cursor.execute("SELECT id, email FROM users WHERE username = %s AND status = %s", (user_input, "active"))

# SECURE: Safe Subprocess Call
import subprocess
subprocess.run(["ls", "-l", user_provided_dir], check=True)
```

## 2. Broken Access Control & IDOR
### Vectors
Users perform actions outside their intended permissions or access objects belonging to other users (Insecure Direct Object Reference).

### Mitigations
- Enforce server-side authorization checks on every endpoint.
- Contextual Ownership Validation: Match session identifier against resource ownership in the database layer.

```python
# SECURE: Enforce resource ownership check
@app.route("/documents/<doc_id>")
def get_document(doc_id):
    user = get_authenticated_user(request)
    doc = db.find_document(doc_id)
    if not doc or doc.owner_id != user.id:
        raise ForbiddenException("Access denied")
    return jsonify(doc)
```

## 3. Server-Side Request Forgery (SSRF)
### Vectors
The server fetches a remote resource without validating the user-supplied URL, allowing attackers to access internal metadata services (e.g., AWS IMDS `169.254.169.254`), internal microservices, or local interfaces (`127.0.0.1`).

### Mitigations
- Maintain an explicit allow-list of domains.
- Block private IPv4/IPv6 ranges (`10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`, `127.0.0.0/8`, `169.254.169.254/16`).
- Resolve DNS server-side and validate the IP address prior to initiating the HTTP request.

## 4. Cross-Site Scripting (XSS)
### Variants
- **Stored XSS**: Malicious script stored in DB and rendered to other users.
- **Reflected XSS**: Script embedded in URL/request and reflected back in response.
- **DOM-based XSS**: Dynamic client-side JavaScript execution via unsafe DOM sinks (`innerHTML`, `eval`).

### Mitigations
- Use modern frontend frameworks (React, Vue) that automatically escape content.
- Context-aware Output Encoding for raw HTML, HTML attributes, JavaScript, and URLs.
- Implement strict Content Security Policy (CSP) headers:
  `Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none';`

## 5. Cross-Site Request Forgery (CSRF)
### Mitigations
- SameSite Cookie Attribute: Set `SameSite=Strict` or `SameSite=Lax`.
- Anti-CSRF Tokens: Cryptographically random tokens checked on state-changing state requests (POST, PUT, DELETE).
