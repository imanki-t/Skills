# Input Validation & Sanitization

Standards for boundary defense, schema validation, output encoding, and safe file handling.

## 1. Boundary Defense & Validation Strategy
- **Allow-list (Positive) Validation**: Define exact allowed data types, formats, character sets, ranges, and patterns. Reject everything else.
- **Never rely on Block-lists**: Blacklisting malicious strings is inherently incomplete.

## 2. Schema Validation Libraries
Enforce strict structural schemas at application entry points.

### Python (Pydantic)
```python
from pydantic import BaseModel, EmailStr, Field, AnyHttpUrl

class UserRegistration(BaseModel):
    username: str = Field(..., min_length=3, max_length=30, pattern="^[a-zA-Z0-9_-]+$")
    email: EmailStr
    age: int = Field(..., ge=18, le=120)
    website: AnyHttpUrl | None = None
```

### TypeScript (Zod)
```typescript
import { z } from "zod";

export const UserRegistrationSchema = z.object({
  username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_-]+$/),
  email: z.string().email(),
  age: z.number().int().min(18).max(120),
});
```

## 3. Regular Expression Safety (ReDoS Protection)
- **ReDoS (Regex Denial of Service)**: Occurs when a regex contains nested quantifiers or overlapping match groups causing exponential backtracking ($O(2^n)$ time complexity).
- **Vulnerable Pattern**: `^(a+)+$` or `([a-zA-Z]+)*$`
- **Safe Alternatives**: Use atomic groups, possessive quantifiers, linear-time regex engines (e.g., RE2, Rust `regex` crate), or set strict execution timeouts.

## 4. Output Encoding Sinks
When outputting data, encode based on context:
- **HTML Body**: Convert `&`, `<`, `>`, `"`, `'`, `/` to HTML entities.
- **HTML Attribute**: Use attribute encoding (e.g., `&quot;`).
- **JavaScript Context**: Encode data as JSON or hex-escaped JS strings.
- **URL Query Parameters**: Percent-encode non-alphanumeric characters (`encodeURIComponent`).

## 5. File Upload Safety
- **Validate File Types**: Check magic bytes (file signature), not just file extensions or Content-Type headers.
- **Randomize Filenames**: Generate UUIDs for stored files to prevent directory traversal or file overwrite attacks.
- **Store Outside Web Root**: Store uploaded files in S3/Cloud Storage or a directory non-executable by the web server.
- **Scan Uploads**: Pass incoming files through an antivirus/malware scanner (e.g., ClamAV).
