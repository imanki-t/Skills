# Secure Memory & Low-Level Coding

Guidance for memory safety, compile-time hardening, buffer overflow prevention, and sanitizer enforcement.

## 1. Memory Safety Vulnerabilities
Low-level languages (C/C++) suffer from critical memory corruption bugs:
- **Buffer Overflow / Underflow**: Writing outside allocated memory bounds.
- **Use-After-Free (UAF)**: Accessing memory after deallocation.
- **Double Free**: Freeing the same memory block twice.
- **Format String Vulnerability**: Passing raw user input as string format parameters (`printf(user_input)`).

## 2. Safe Language Paradigms
- **Rust**: Language-level compile-time memory safety via ownership, borrowing, and lifetime rules (without garbage collection).
- **Modern C++ (C++20/C++23)**: Avoid raw pointers (`new`/`delete`). Use smart pointers (`std::unique_ptr`, `std::shared_ptr`), `std::span`, and range checking.

## 3. Compiler Hardening Flags (GCC/Clang)
Enforce maximum compiler security mitigations during compilation:

```makefile
CFLAGS += -O2
CFLAGS += -Wall -Wextra -Werror
CFLAGS += -fstack-protector-strong      # Stack Canary protection
CFLAGS += -D_FORTIFY_SOURCE=2           # Compile-time & run-time buffer checks
CFLAGS += -fPIE -pie                    # Position-Independent Executable (ASLR)
CFLAGS += -Wl,-z,relro,-z,now           # Full RELRO (Read-Only Relocations)
CFLAGS += -fcf-protection=full          # Control Flow Integrity (CFI)
```

## 4. Runtime Sanitizers
Use LLVM sanitizers during testing and CI execution to catch memory bugs:
- **AddressSanitizer (ASan)**: Detects out-of-bounds access, UAF, double free.
- **UndefinedBehaviorSanitizer (UBSan)**: Catches integer overflows, null pointer dereferences.
- **ThreadSanitizer (TSan)**: Catches data races in multithreaded code.

```bash
# Compile with ASan & UBSan
clang++ -fsanitize=address,undefined -g -O1 main.cpp -o main_sanitized
```

## 5. Safe String Operations in C
- Replace dangerous functions:
  - `strcpy` -> `snprintf` or `strlcpy`
  - `strcat` -> `strlcat`
  - `gets` -> `fgets`
  - `sprintf` -> `snprintf`

```c
// SECURE C String Copy
char dest[32];
snprintf(dest, sizeof(dest), "%s", src);
```
