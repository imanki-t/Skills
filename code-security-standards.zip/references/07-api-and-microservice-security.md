# API & Microservice Security

Standards for rate limiting, Zero Trust service networking, GraphQL security, and CORS policies.

## 1. Rate Limiting & Throttling
Protect endpoints from Denial of Service (DoS) and brute-force attacks.
- **Algorithms**: Token Bucket, Leaky Bucket, Sliding Window Log.
- **Distributed Rate Limiting**: Store counters in centralized, low-latency stores (Redis) using atomic scripts.

```python
# FastAPI + Redis Rate Limiter Pattern
from fastapi import FastAPI, Request, HTTPException
import redis, time

r = redis.Redis(host='localhost', port=6379, db=0)

def rate_limit(client_id: str, limit: int = 100, window: int = 60):
    key = f"rate:{client_id}:{int(time.time() // window)}"
    current = r.incr(key)
    if current == 1:
        r.expire(key, window)
    if current > limit:
        raise HTTPException(status_code=429, detail="Too Many Requests")
```

## 2. Microservice Zero Trust Architecture
- **Mutual TLS (mTLS)**: Authenticate and encrypt all inter-service communication.
- **Service Identity (SPIFFE / SPIRE)**: Issue cryptographic identities (SVIDs) to workloads based on runtime attestation rather than IP addresses or static credentials.

## 3. GraphQL Security
GraphQL endpoints present unique attack vectors due to single-endpoint architecture and deep nesting.
- **Query Depth Limiting**: Prevent recursive deeply-nested queries from overloading database engines.
- **Query Complexity Analysis**: Assign cost scores to fields; reject queries exceeding complexity thresholds.
- **Disable Introspection in Production**: Prevent schema scraping in public environments.

## 4. Cross-Origin Resource Sharing (CORS)
- **Avoid Wildcards with Credentials**: Never set `Access-Control-Allow-Origin: *` when `Access-Control-Allow-Credentials: true` is enabled.
- **Explicit Origin Allowlist**: Dynamically check request origin against a trusted list.

```javascript
// SECURE: Express CORS Configuration
const allowedOrigins = ['https://app.example.com', 'https://admin.example.com'];

app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('CORS Not Allowed'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
```
