# DevSecOps, CI/CD & Automated Security

Integration of SAST, DAST, Secret Scanning, and supply chain integrity into CI/CD automation.

## 1. Shift-Left Security Pipeline Overview
```
[ Commit ] -> [ Pre-Commit Hooks (Gitleaks, Lint) ] 
          -> [ CI Build ] -> [ SAST (Semgrep) & Secret Scan ] 
          -> [ Container Scan (Trivy) ] -> [ Artifact Signing (Cosign) ] 
          -> [ Staging Deploy ] -> [ DAST (OWASP ZAP) ] -> [ Production ]
```

## 2. Static Application Security Testing (SAST)
- **Semgrep**: Lightweight, rule-based static analysis for custom code patterns.
- **SonarQube**: Deep static analysis for code quality and vulnerability detection.

```yaml
# GitHub Actions: Semgrep SAST Step
- name: Semgrep SAST Scan
  uses: semgrep/semgrep-action@v1
  with:
    config: p/ci
```

## 3. Secret Scanning in CI & Git Pre-Commit
Prevent credentials from entering git history.
- **Tools**: Gitleaks, TruffleHog.

```yaml
# Pre-Commit Hook Configuration (.pre-commit-config.yaml)
repos:
  - repo: https://github.com/gitleaks/gitleaks
    rev: v8.18.0
    hooks:
      - id: gitleaks
```

## 4. Dynamic Application Security Testing (DAST)
Perform automated vulnerability scanning against running applications in staging environments.
- **OWASP ZAP**: Automated web scanner for XSS, SQLi, broken headers, and misconfigurations.

```bash
# Run ZAP Baseline Scan in Docker
docker run -v $(pwd):/zap/wrk/:rw -t ghcr.io/zaproxy/zaproxy:stable zap-baseline.py     -t https://staging.example.com -g gen.conf -r testreport.html
```

## 5. Artifact Signing & Provenance Verification
Sign compiled binaries and container images using Sigstore / Cosign.

```bash
# Sign container image with keyless Cosign
cosign sign --key k8s://kms-key my-registry.com/app:v1.0.0
```
