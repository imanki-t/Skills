# Authentication & Authorization Standards

Guidelines for identity verification, token management, role-based and attribute-based access controls.

## 1. OAuth 2.0 & OpenID Connect (OIDC)
- **Use Authorization Code Flow with PKCE**: Proof Key for Code Exchange is mandatory for single-page applications (SPAs), mobile apps, and confidential clients.
- **Validate State & Nonce**: Prevent login CSRF and replay attacks by validating state parameters and ID token nonces.
- **Token Storage**:
  - Never store access/refresh tokens in LocalStorage or SessionStorage (vulnerable to XSS).
  - Use `HttpOnly`, `Secure`, `SameSite=Strict` cookies for web clients.

## 2. JWT Security Best Practices
- **Explicit Algorithm Verification**: Reject `alg: "none"` or algorithm switching (e.g., forcing RS256 to HS256). Explicitly pin expected algorithms in verification configuration.
- **Short Lifetime**: Set access token expiration (`exp`) to 5-15 minutes.
- **Token Invalidation**: Maintain token revocation lists (Redis bitset/bloom filter) or refresh-token rotation strategies for emergency logout/revocation.

```python
# SECURE: PyJWT Verification
import jwt

decoded = jwt.decode(
    token,
    PUBLIC_KEY,
    algorithms=["RS256"],  # Explicitly enforce algorithm
    options={"verify_exp": True, "require": ["exp", "iss", "aud"]}
)
```

## 3. Password Hashing Standards
- **Approved Password Hashers**: Argon2id (primary recommendation), bcrypt (work factor >= 12), or PBKDF2-HMAC-SHA256 (>= 600,000 iterations).
- **Never use legacy hashes**: MD5, SHA1, plain SHA256/SHA512 are forbidden for password storage.

```python
from argon2 import PasswordHasher

ph = PasswordHasher(
    time_cost=3,        # 3 iterations
    memory_cost=65536,  # 64 MiB
    parallelism=4
)
hashed_pw = ph.hash("UserSecretPassword123!")
# Verification:
ph.verify(hashed_pw, "UserSecretPassword123!")
```

## 4. Role-Based (RBAC) & Attribute-Based (ABAC) Access Control
- **Principle of Least Privilege**: Default to implicit deny (`deny-all`).
- **Decouple AuthZ from Business Logic**: Use policy engines like Open Policy Agent (OPA) or Cedar for centralized, auditable access rules.

```rego
# Open Policy Agent (OPA) Example
package app.authz

default allow = false

allow {
    input.user.roles[_] == "admin"
}

allow {
    input.user.id == input.resource.owner_id
    input.action == "read"
}
```

## 5. Multi-Factor Authentication (MFA) & Passkeys
- **WebAuthn / Passkeys**: FIDO2 asymmetric key pairs stored in hardware/secure enclaves (phishing-resistant MFA).
- **TOTP (RFC 6238)**: Time-based One-Time Password using HMAC-SHA1/SHA256 with 30-second step windows.
