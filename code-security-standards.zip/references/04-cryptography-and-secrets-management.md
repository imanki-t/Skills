# Cryptography & Secrets Management

Industrial standards for data encryption at rest, data in transit, key management, and zero-leak credential hygiene.

## 1. Approved Cryptographic Primitives
| Category | Recommended Standard | Legacy / Forbidden |
| :--- | :--- | :--- |
| **Symmetric Encryption** | AES-256-GCM, ChaCha20-Poly1305 | DES, 3DES, AES-CBC (without HMAC), RC4 |
| **Asymmetric Keys** | RSA (>= 3072 bit), Ed25519, ECDSA (P-256) | RSA < 2048 bit, DSA |
| **Cryptographic Hashing** | SHA-256, SHA-384, SHA-3, BLAKE3 | MD5, SHA1 |
| **Key Derivation (KDF)** | HKDF, Argon2id, PBKDF2 | Simple SHA hashing |

## 2. Authenticated Encryption (AEAD)
Always use Authenticated Encryption with Associated Data (AEAD) to guarantee both confidentiality and integrity.

```python
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os

key = AESGCM.generate_key(bit_length=256)
aesgcm = AESGCM(key)
nonce = os.urandom(12)  # Cryptographically secure random 96-bit nonce

data = b"Sensitive industrial payload"
associated_data = b"authenticated-metadata"

ciphertext = aesgcm.encrypt(nonce, data, associated_data)
# Decryption
decrypted = aesgcm.decrypt(nonce, ciphertext, associated_data)
```

## 3. Secrets Management Architecture
- **Zero Secrets in Code**: Credentials, API keys, database connection strings, and certificates must NEVER exist in source code or docker images.
- **Environment Injectors & Key Vaults**:
  - HashiCorp Vault, AWS Secrets Manager, Azure Key Vault, GCP Secret Manager.
  - Dynamically lease ephemeral credentials where possible (e.g., short-lived DB credentials).

## 4. Key Rotation & Lifecycle
- **Key Rotation**: Enforce automatic key rotation schedules (e.g., annually or per 1,000,000 operations).
- **Envelope Encryption**: Encrypt data using a Data Encryption Key (DEK); encrypt the DEK using a Master Key / Key Encryption Key (KEK) stored in a Hardware Security Module (HSM).

## 5. TLS 1.3 & Transport Security
- Disable SSLv2, SSLv3, TLS 1.0, TLS 1.1.
- Mandate TLS 1.3 or TLS 1.2 with strong cipher suites (`ECDHE-ECDSA-AES128-GCM-SHA256`, `ECDHE-RSA-AES256-GCM-SHA384`).
- Enforce HTTP Strict Transport Security (HSTS):
  `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload`
