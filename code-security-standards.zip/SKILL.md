---
name: code-security-standards
description: Industrial-grade security standards and secure coding practices across application, cloud, supply chain, and memory domains. Use when reviewing code for vulnerabilities, designing secure architectures, auditing codebases, configuring DevSecOps pipelines, or implementing cryptography and authentication.
---

# Code Security Standards

Industrial-grade security measures, threat modeling frameworks, and defensive programming standards for building secure, resilient software systems.

## When to Use
Use this skill when:
- Auditing codebases or Pull Requests for security vulnerabilities and compliance.
- Architecting authentication, authorization, or cryptographic modules.
- Hardening APIs, microservices, databases, or cloud environments.
- Implementing DevSecOps pipelines, SAST/DAST tooling, or secret scanning.
- Securing software supply chains, dependencies, and container environments.
- Preventing memory-safety exploits or injection vulnerabilities.

## Core Industrial Security Framework
Security in modern software systems relies on continuous Defense-in-Depth, Principle of Least Privilege, and Zero Trust Architecture across 10 key security domains:

1. **Web & API Defense**: Protection against OWASP Top 10 vulnerabilities (SQLi, XSS, CSRF, SSRF, IDOR).
2. **Input Validation & Sanitization**: Strict schema validation, parameterization, and output encoding.
3. **Authentication & Access Control**: OAuth 2.0 / OIDC, JWT security, RBAC/ABAC, Session security, and Passkeys.
4. **Cryptography & Secrets Management**: Modern ciphers (AES-GCM, ChaCha20-Poly1305), Argon2id hashing, TLS 1.3, and Vault integration.
5. **Supply Chain Security**: SBOM generation (SPDX/CycloneDX), dependency pinning, lockfile verification, and vulnerability scanning.
6. **Memory Safety & Low-Level Security**: Prevention of buffer overflows, use-after-free, dangling pointers, ASLR, DEP/NX, and sanitizers.
7. **API & Microservice Security**: Rate limiting, mTLS, GraphQL query depth limits, and Zero Trust identity.
8. **Cloud-Native & Container Security**: Distroless containers, non-root execution, IaC scanning, and K8s RBAC policies.
9. **DevSecOps & Automated Security**: SAST, DAST, Secret scanning (Gitleaks), and SLSA provenance generation.
10. **Logging, Auditing & Incident Response**: Secure logging (PII redaction), audit trails, and tamper-evident logs.

## Domain Reference Guides
Detailed guidelines and concrete implementations are organized across 10 reference files:

- [01: OWASP Top 10 & Web Security](references/01-owasp-top-10-and-web-security.md)
- [02: Input Validation & Sanitization](references/02-input-validation-and-sanitization.md)
- [03: Authentication & Authorization](references/03-authentication-and-authorization.md)
- [04: Cryptography & Secrets Management](references/04-cryptography-and-secrets-management.md)
- [05: Supply Chain & Dependency Security](references/05-supply-chain-and-dependency-security.md)
- [06: Secure Memory & Low-Level Coding](references/06-secure-memory-and-low-level-coding.md)
- [07: API & Microservice Security](references/07-api-and-microservice-security.md)
- [08: Cloud-Native & Container Security](references/08-cloud-native-and-container-security.md)
- [09: DevSecOps, CI/CD & SAST/DAST](references/09-devsecops-cicd-and-sast-dast.md)
- [10: Logging, Auditing & Incident Response](references/10-logging-auditing-and-incident-response.md)

## Security Review Workflow
1. **Identify High-Risk Entry Points**: User input handlers, authentication routes, file uploads, external API integration points.
2. **Validate Input & Boundaries**: Check for strict typing, schema enforcement, length limits, and parameterization.
3. **Audit Access Control**: Verify object-level authorization (IDOR checks) and role/permission checks before data access.
4. **Check Cryptographic Usage**: Ensure approved ciphers (AES-256-GCM, Argon2id) and verify keys/tokens are not hardcoded.
5. **Review Dependencies & Build System**: Check for pinned versions, lockfiles, and absence of known CVEs.
6. **Verify Logging & Error Handling**: Ensure sensitive data (passwords, tokens, PII) is redacted and errors fail safely without disclosing stack traces.

## Critical Gotchas
- **Hardcoded Secrets**: Never commit credentials, private keys, or tokens to version control.
- **Insecure Deserialization**: Avoid native object deserialization (pickle, eval, unsafe YAML loading) on untrusted inputs.
- **Fail-Open Logic**: Ensure error states and exception handlers default to denying access.
- **Broken Object Level Authorization (BOLA/IDOR)**: Never rely solely on user-provided IDs without validating ownership against the authenticated session context.
