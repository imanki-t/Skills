# Code Optimization: Algorithmic Efficiency & CPU Cache Locality

## Overview

At modern hardware scales, memory access speeds dominate CPU performance. A main memory (DRAM) fetch takes $100\text{--}200$ CPU cycles, whereas L1 cache access takes $4\text{--}5$ cycles. Consequently, data structure design and memory access patterns often impact execution speed far more than micro-level code optimizations.

---

## 1. CPU Cache Hierarchy & Memory Alignment

### Memory Hierarchy Timings
- **L1 Cache**: ~1-2 ns (32–64 KB per core)
- **L2 Cache**: ~3-5 ns (512 KB – 1 MB per core)
- **L3 Cache**: ~10-20 ns (Shared 32-128 MB)
- **DRAM (Main Memory)**: ~60-100 ns (Cache miss latency penalty)

### Cache Line Mechanics
- Hardware reads memory in contiguous **64-byte Cache Lines**.
- Accessing element $A[0]$ automatically fetches $A[1 \dots 7]$ into L1/L2 cache if data is contiguous.
- Node-based structures (linked lists, trees) cause **pointer chasing**, jumping across non-contiguous DRAM locations and triggering cache misses on every access.

---

## 2. Structure Layout: AoS vs. SoA

When processing collections of structured entities (e.g., embeddings, chat facts, bounding boxes):

### Array of Structures (AoS)
```cpp
struct Entity {
  float embedding[1536]; // 6144 bytes
  uint64_t id;
  uint32_t flags;
};
Entity entities[10000]; // Poor locality if iterating only over IDs or flags
```

### Structure of Arrays (SoA)
```cpp
struct EntityCollection {
  std::vector<uint64_t> ids;     // Contiguous IDs: 8 bytes per element (8 IDs per cache line)
  std::vector<uint32_t> flags;   // Contiguous flags
  std::vector<float> embeddings; // Contiguous flat vector array for SIMD
}; // Optimal cache utilization and SIMD vectorization
```

---

## 3. Branch Predictability & Branchless Code

Modern CPUs use deep pipelines ($14\text{--}20+$ stages) and speculative execution. A branch misprediction flushes the pipeline, incurring a $15\text{--}20$ cycle penalty.

### Keeping Hot Loops Branchless
- **Branchless Min/Max/Clamp**: Use bitwise operations or conditional moves (`CMOV` instruction) instead of `if-else`.
- **Sorting Data**: Sorting input arrays before iterating allows branch predictors to predict branches with $>99\%$ accuracy.

```python
# Branchy loop (unpredictable condition)
for item in items:
    if item.score > threshold:
        active_count += 1

# Branchless equivalent (using boolean evaluation)
for item in items:
    active_count += int(item.score > threshold)
```

---

## 4. Application to AI Vector Search & Index Locality

1. **Flat Dense Vector Buffers**: Store high-dimensional embeddings ($1536$-dim or $768$-dim) in flat contiguous `float32`/`float16` buffers rather than nested arrays to maximize SIMD dot-product throughput (AVX-512 / ARM NEON).
2. **Quantization Locality**: Use Scalar Quantization (SQ8) or Product Quantization (PQ) to fit embedding indices into L3 cache, converting 1536-byte float vectors into 1536-byte byte vectors ($4\times$ memory reduction).
3. **HNSW Vector Graph Traversals**: Keep node neighbor lists tightly packed in contiguous memory blocks to minimize DRAM misses during graph navigation.
