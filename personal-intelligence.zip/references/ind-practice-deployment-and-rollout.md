# Industrial Practices: Production Rollouts, Canary Releases & DORA Metrics

## Overview

Deploying software changes to production without user-facing disruption requires structured progressive delivery mechanisms. Industrial-grade delivery decouples code deployment from feature enablement, utilizes automated canary testing, and tracks engineering organizational velocity using DORA metrics.

---

## 1. Progressive Delivery & Rollout Strategies

```
+-------------------------------------------------------------------------+
|                       Canary Deployment Lifecycle                       |
|                                                                         |
|  [ Baseline Build (99% Traffic) ]    [ Canary Build (1% Traffic) ]       |
|                                                     |                   |
|                                      Automated Telemetry Audit          |
|                                      (Check p99 Latency & Error Rate)   |
|                                                     |                   |
|                                      Pass? Scale Traffic:               |
|                                      1% -> 10% -> 50% -> 100%           |
+-------------------------------------------------------------------------+
```

### Canary Deployments
- Route a small fraction ($1\text{--}5\%$) of production traffic to a newly deployed canary build while routing remaining traffic to baseline builds.
- Automatically compare canary telemetry against baseline builds (p99 latency, CPU usage, memory leaks, error rates).
- Automatically roll back if canary metrics breach predefined error budget thresholds.

### Blue-Green Deployments
- Maintain two identical production environments (Blue = Active, Green = Staging).
- Deploy new release to Green, run health checks, and switch router/load-balancer traffic seamlessly from Blue to Green. Allows instant rollback by switching traffic back to Blue.

---

## 2. Zero-Downtime Schema & Store Migrations

When altering database schemas or KV fact storage schemas without taking down live services, apply the **Expand and Contract (Parallel Run)** pattern:

1. **Expand**: Add new database column/field without removing the old field.
2. **Dual Write**: Update application code to write to both old and new fields simultaneously.
3. **Backfill**: Run a background migration script to copy historical data from old fields to new fields.
4. **Contract**: Update application code to read exclusively from new fields, then deprecate and remove old fields.

---

## 3. DORA Metrics & Organizational Velocity

The DevOps Research and Assessment (DORA) institute identifies four key metrics that quantify software delivery performance:

| DORA Metric | Definition | Elite Performance Benchmark |
|---|---|---|
| **Deployment Frequency** | How often code is deployed to production | Multiple deployments per day |
| **Lead Time for Changes** | Time from code commit to production release | $< 1\text{ hour}$ |
| **Change Failure Rate (CFR)** | % of deployments requiring emergency fixes/rollbacks | $0\text{--}15\%$ |
| **Time to Restore Service (MTTR)** | Time required to recover from a production failure | $< 1\text{ hour}$ |

---

## 4. Application to AI Memory Service Rollouts

1. **Prompt & Memory Schema Canarying**: When rolling out new fact extraction prompt templates or JSON schema updates, canary the prompt changes on $1\%$ of user threads. Verify that JSON parse errors and extraction failure rates remain at $0\%$ before expanding to $100\%$.
2. **Multi-Region Failover for Fact Stores**: Replicate Redis/Postgres KV fact stores across primary and secondary cloud regions using asynchronous replication to guarantee sub-second memory recovery if a cloud region experiences an outage.
