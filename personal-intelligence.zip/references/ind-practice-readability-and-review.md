# Industrial Practices: Readability, Style & Code Review Culture

## Overview

Industrial-grade code is designed to survive contact with hundreds of engineers, years of maintenance, and continuous feature evolution. Big tech engineering organizations (Google, Meta, Microsoft, NVIDIA, Apple) converge on a foundational truth: **code is read far more often than it is written**. Every practice in this guide optimizes for the future reader, reviewer, and maintainer.

---

## 1. Readability & Consistency

A consistent, boring style applied universally across a codebase is superior to clever individual coding styles applied inconsistently. Consistency enables fast code reviews, reduces cognitive load, and unlocks automated tooling.

### Key Readability Rules
1. **Automated Formatting Over Debate**: Never discuss formatting (indentation, line length, quote styles) in code reviews. Enforce automatic formatting via pre-commit hooks and CI linters (e.g., `Black`/`Ruff` for Python, `gofmt` for Go, `clang-format` for C++, `prettier` for TypeScript).
2. **Self-Documenting Code & Intentful Naming**:
   - Variable and function names must express intent clearly at the call site.
   - Prefer clarity over brevity (`user_fact_store` over `ufs`).
3. **Comments Explain "Why", Not "What"**:
   - The code itself describes *what* is happening. Comments must document *why* non-obvious choices or trade-offs were made.
   - Example: `# Using custom arena allocator here because standard vector re-allocations cause p99 latency spikes during rapid chat turns.`

---

## 2. Code Review Discipline (Google / Meta / Microsoft Framework)

Code review is treated as a collaborative discipline for maintaining **codebase health**, not a gatekeeping or fault-finding exercise.

```
+--------------------------------------------------------------------------+
|                      Industrial Code Review Standard                     |
|                                                                          |
|  1. Design & Architecture  --> Is the overall approach sound?            |
|  2. Correctness            --> Does it handle edge cases and bugs?       |
|  3. Complexity             --> Is it overly engineered?                  |
|  4. Tests                  --> Are automated tests included and clean?   |
|  5. Naming & Style         --> Is it readable and consistent?            |
+--------------------------------------------------------------------------+
```

### Review Principles
- **Approve When Health Improves**: Do not block a PR chasing perfection. If the change improves codebase health and passes tests, approve it. Out-of-scope polish should be logged as follow-up issues.
- **Keep Diffs Small & Atomic**: PRs should ideally be $<200\text{--}400$ lines of code. Small PRs receive deeper, faster reviews with lower bug defect rates.
- **Explicit Severity Labels**:
  - `Blocker:` Must be fixed before merging (e.g., correctness bug, security risk, missing test).
  - `Nit:` Optional suggestion or cosmetic fix (e.g., variable naming preference).
  - `Question:` Seeking clarification on intent.
- **Blameless & Respectful Communication**: Focus feedback strictly on the code, never the author ("The function name could be clearer" vs "You named this poorly").

---

## 3. Application to AI System Codebase

1. **Explicit Schema Definitions**: Define strict, readable type annotations (Pydantic models, Protobuf schemas, or TypeScript interfaces) for all LLM outputs and KV fact stores to eliminate ambiguity.
2. **Reviewing Prompt Engineering**: Treat prompts as code. Code reviews for prompt updates must evaluate edge cases, token footprint, regression safety, and prompt injection resilience.
