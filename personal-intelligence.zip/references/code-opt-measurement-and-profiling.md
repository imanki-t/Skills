# Code Optimization: Measurement & Profiling

## Overview

Optimization without measurement is speculation. In large-scale engineering organizations (Google, Meta, Microsoft, NVIDIA, Apple), performance tuning begins and ends with empirical data. Premature optimization wastes developer time and harms maintainability; targeted optimization on measured hot paths delivers orders-of-magnitude improvements.

---

## 1. The Profiling & Measurement Ecosystem

### Continuous & Fleet-Wide Profiling
- **Google-Wide Profiling (GWP)**: Continuous background profiling sampling a fraction of fleet hardware to record CPU, memory, and lock contention stacks with $<1\%$ overhead.
- **Linux `perf`**: Hardware performance counter analysis (cache misses, branch mispredictions, CPU cycles).
- **Go/C++ `pprof`**: CPU sampling, memory allocation profiling, block/mutex contention profiling.
- **Python Profiling**: `scalene` (CPU, memory, GPU allocation separation) and `py-spy` (non-intrusive CPython sampling).
- **Apple Instruments**: System-wide energy, thermal, CPU, and Swift ARC allocation profiling.

### Key Latency Metrics & SLAs
- **Tail Latency Focus**: Always track p90, p99, and p99.9 tail latencies rather than mean/median. High mean latency indicates a general slow path; high p99 latency indicates lock contention, GC pauses, or I/O spikes.
- **LLM Performance Metrics**:
  - **TTFT (Time To First Token)**: Latency from request start to initial token output (dominated by prompt prefill/context processing).
  - **TPOT (Time Per Output Token)**: Inter-token generation latency (dominated by memory bandwidth / auto-regressive decoding).
  - **QPS per Dollar / Watt**: Throughput efficiency per infrastructure cost unit.

---

## 2. Microbenchmarking Best Practices

Microbenchmarks isolate specific routines to measure throughput and latency without full system noise.

### Rules of Microbenchmarking
1. **Prevent Compiler Dead-Code Elimination**: Ensure return values or output buffers are consumed using sink idioms (e.g., `benchmark::DoNotOptimize` in C++ or `b.N` iterations in Go).
2. **Warm-Up Runs**: Allow CPU caches, JIT compilers (PyTorch/PyPy/Java), and hardware power states to reach steady state before measuring.
3. **Statistical Significance**: Run multiple iterations ($N \ge 30$) and report confidence intervals (mean $\pm$ standard deviation).
4. **Isolate Environment**: Disable CPU frequency scaling (governor set to `performance`), ASLR if measuring cache effects, and hyperthreading noise.

```cpp
// C++ Google Benchmark Example (Preventing Dead Code Elimination)
static void BM_FactExtractionParsing(benchmark::State& state) {
  std::string raw_json = R"({"add_facts":["User prefers Python"]})";
  for (auto _ : state) {
    auto parsed = ParseFactJson(raw_json);
    benchmark::DoNotOptimize(parsed);
    benchmark::ClobberMemory();
  }
}
BENCHMARK(BM_FactExtractionParsing);
```

---

## 3. Flamegraph Analysis & Bottleneck Identification

Flamegraphs visualize call stacks to identify where CPU cycles or memory allocations accumulate.

- **X-Axis**: Represents the population of samples (sorted alphabetically by call stack, not chronologically). Wider frames consume more CPU cycles / allocations.
- **Y-Axis**: Represents stack depth (bottom is entry point, top is leaf function).
- **Types of Flamegraphs**:
  - **CPU Flamegraphs**: Identifies compute-heavy functions (e.g., regex, JSON parsing, embedding normalization).
  - **Off-CPU Flamegraphs**: Identifies I/O wait times, thread blocking, and lock contention (essential for LLM API calls and DB queries).
  - **Memory Flamegraphs**: Shows object allocation sources to target GC pressure and memory leaks.

---

## 4. Application to AI Memory Architecture

When profiling a multi-tiered memory pipeline (e.g., `gemini-personal-intelligence`):
1. **Measure Fast Path vs. Slow Path**: Ensure the synchronous response path ($\text{Latency} < 50\text{ ms}$) never invokes heavy vector search or background fact extraction.
2. **Profile KV Store Lookup**: Verify Redis/SQLite queries complete within $2\text{--}5\text{ ms}$.
3. **Audit Token Budget**: Continuously monitor system prompt token sizes to avoid bloating input context and driving up TTFT latency.
