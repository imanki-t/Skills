# Code Optimization: Compiler & Build-Level Optimizations

## Overview

Modern compilers (Clang, GCC, Rustc, Go compiler) possess sophisticated optimization passes capable of restructuring code, inlining functions, vectorizing loops, and eliminating dead code. Enabling build-level optimizations and Profile-Guided Optimization (PGO) allows systems to achieve $15\text{--}40\%$ performance improvements without altering source code.

---

## 1. Compiler Optimization Levels & Flags

### C / C++ / Rust Optimization Levels
- `-O2`: Standard production optimization level. Balance between code size, compile time, and performance without risky trade-offs.
- `-O3`: Aggressive optimization. Enables aggressive loop vectorization, loop unrolling, and inlining (may increase binary size).
- `-Ofast`: Enables `-O3` plus non-IEEE floating-point optimizations (e.g., fast-math, reassociating math expressions). *Use with caution in scientific or exact numerical software.*
- Target Architecture Flags (`-march=native`, `-mcpu=native`): Instructs the compiler to emit instruction extensions (AVX-512, FMA, NEON) supported by the target host CPU.

---

## 2. Profile-Guided Optimization (PGO / AutoFDO) & ThinLTO

### Profile-Guided Optimization (PGO)
Static compilers make heuristic assumptions about which branches are taken and which functions are hot. PGO replaces heuristics with actual execution profiles collected from production traffic.

#### PGO Workflow
1. **Instrumented Build**: Compile the binary with instrumentation enabled (`-fprofile-generate` or GCC/Clang equivalent).
2. **Profile Generation**: Run realistic workload / production scenario to generate `.profraw` execution traces.
3. **Optimized Re-compile**: Feed profile data back to the compiler (`-fprofile-use`). Compiler optimizes:
   - **Hot/Cold Code Splitting**: Places hot execution paths adjacent in memory to reduce L1 instruction cache misses.
   - **Branch Probability**: Re-orders assembly jumps so the most common branch executes straight-through.
   - **Inlining Decisions**: Aggressively inlines functions proven to be hot at runtime.

### Link-Time Optimization (LTO / ThinLTO)
Traditional compilation optimizes each translation unit (`.cpp` / `.rs` file) independently. LTO preserves intermediate representation (IR) into object files and performs whole-program analysis at link time, enabling cross-file function inlining and dead code elimination.

---

## 3. Compile-Time Evaluation (`constexpr` & Templates)

Move computations from runtime to compile time wherever possible.

- **C++ `constexpr` / `consteval`**: Evaluates complex functions, hash maps, and lookup tables during compilation.
- **Rust Const Evaluation (`const fn`)**: Computes static constants and table lookup structures at compile time.
- **Template Metaprogramming**: Generates specialized, zero-overhead type-specific code without dynamic virtual table dispatch.

```cpp
// Compile-time generation of a 256-element byte lookup table
constexpr auto GenerateByteTable() {
  std::array<uint8_t, 256> table{};
  for (size_t i = 0; i < 256; ++i) {
    table[i] = static_cast<uint8_t>(i ^ 0xAA);
  }
  return table;
}
constexpr auto BYTE_TABLE = GenerateByteTable(); // $0\text{ ms}$ runtime cost
```

---

## 4. CI Performance Gating & Regression Detection

Prevent performance regressions from reaching production.

1. **Automated Microbenchmarks in CI**: Execute benchmark suites on dedicated, non-virtualized runner machines for every PR.
2. **Threshold Regression Checking**: Fail CI builds if p99 latency increases by $>5\%$ or throughput drops by $>3\%$.
3. **Continuous Performance Tracking**: Graph benchmark results across commits to identify gradual performance degradation.
