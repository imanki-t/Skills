# Industrial Practices: Reliability, Observability & Resilience

## Overview

Software reliability is an explicit trade-off between engineering velocity and system stability. Large-scale engineering organizations design systems to remain operational during partial infrastructure outages, third-party API degradations, and traffic spikes using observability instrumentation, resilience patterns, and blameless incident postmortems.

---

## 1. The Three Pillars of Observability

```
+--------------------------------------------------------------------------+
|                     Modern Observability Architecture                    |
|                                                                          |
|  1. Structured Logs  --> JSON formatted, contextual correlation_id        |
|  2. Metrics          --> Numerical time-series (Prometheus / OpenTelemetry) |
|  3. Traces           --> Request lifecycles across services (Jaeger/Tempo)  |
+--------------------------------------------------------------------------+
```

### Structured Logging Standards
- Always log in structured **JSON format**.
- Include standard context fields on every log entry: `timestamp`, `service`, `environment`, `trace_id`, `user_id`, `level`.
- Never log raw sensitive PII or credentials.

### Key Operational Metrics
- **The Four Golden Signals** (Google SRE Book):
  1. **Latency**: Time taken to service a request (track p50, p90, p99).
  2. **Traffic**: Demand placed on the system (e.g., QPS, HTTP requests/sec).
  3. **Errors**: Rate of requests that fail (e.g., HTTP 5xx errors, API timeout rate).
  4. **Saturation**: Utilization of hardware resources (CPU %, Memory %, Queue depth).

---

## 2. Resilience Design Patterns

### Circuit Breakers
- Monitor error rates of downstream dependencies (e.g., LLM APIs, external vector DBs).
- If downstream error rate exceeds a threshold (e.g., $>50\%$ failure over 10s), **open the circuit breaker** immediately to fail fast without flooding degraded downstream servers.
- Periodically allow test requests through (**half-open state**) to detect recovery.

### Fallback Strategies & Graceful Degradation
- **Tiered Model Fallbacks**: If the primary LLM API (e.g., Claude 3.5 Sonnet / Gemini 1.5 Pro) times out or returns HTTP 503, fallback automatically to a fast alternative model (Gemini 2.0 Flash / GPT-4o-mini).
- **Graceful Feature Degradation**: If vector search database is unreachable, bypass Tier 3 long-term recall and fulfill the response using Tier 1 context buffer and Tier 2 KV facts alone.

---

## 3. Incident Management & Blameless Postmortems

When production outages occur:
- **Prioritize Mitigation First**: Focus on restoring service (failing over, toggling feature flags, rolling back builds) before debugging root causes.
- **Blameless Postmortems**: Focus on systemic process and architectural weaknesses rather than human error.
- **The 5 Whys**: Drill down to systemic root causes to generate actionable preventative tickets.
