---
name: code-optimization
description: Guidance for profiling, benchmarking, and optimizing code according to industrial standards from companies like Google, Meta, Microsoft, NVIDIA, and Apple. Covers measurement-driven optimization, algorithmic efficiency, CPU cache locality, memory management, compiler optimizations (PGO/LTO), concurrency, I/O efficiency, and performance regression prevention in CI. Use when the user asks to optimize, profile, benchmark, speed up, or reduce memory usage of code; asks for performance best practices or how big tech companies optimize software; or requests a code performance audit or refactoring for efficiency.
---
# Industrial Code Optimization

## Philosophy

Code optimization in large-scale engineering organizations (such as Google, Meta, Microsoft, NVIDIA, Amazon, and Apple) is governed by one fundamental principle: **measure, don't guess**. 

Premature optimization wastes engineering time and compromises code readability. Production-grade optimization focuses strictly on verified hot paths identified through continuous profiling and microbenchmarking data, maintaining a careful balance between performance, maintainability, and correctness.

---

## Detailed Reference Guides

This skill includes 6 specialized reference files located in the `references/` directory for deep-dive execution guidelines, code samples, and architectural patterns:

1. **`references/continuous-profiling-and-autofdo.md`**: Fleet-wide continuous profiling (Google-Wide Profiling / GWP), AutoFDO sampling toolchains, post-link binary optimizers (BOLT, Propeller), ThinLTO, and automated CI feedback loops.
2. **`references/memory-and-cache-optimization.md`**: CPU cache line alignment, false sharing prevention, SoA vs AoS layouts, SIMD hash probing (Abseil Swiss Tables), production allocators (TCMalloc, Temeraire, jemalloc, mimalloc), zero-copy views, and arena allocators.
3. **`references/concurrency-and-hardware-acceleration.md`**: Lock contention elimination, lock-free SPSC queues with memory barriers, Linux `io_uring` ring-buffer I/O, SIMD auto-vectorization and intrinsics, and CUDA GPU kernel optimizations.
4. **`references/industrial-benchmarking-and-ci.md`**: Statistical microbenchmarking (Google Benchmark, JMH), tail latency engineering ("The Tail at Scale", p99 / p99.9 TP999, hedged requests), key efficiency metrics (QPS/core, $/1M ops), and CI regression gating.
5. **`references/language-runtime-and-gc-tuning.md`**: Language-specific runtimes: C++ (`constexpr`, move semantics), Go (`GOMEMLIMIT`, escape analysis, `sync.Pool`), Java/JVM (ZGC ultra-low pauses <1ms, GraalVM AOT), Rust (`jemalloc`, inline directives), and Python (`torch.compile`, NumPy vectorization).
6. **`references/network-io-and-serialization.md`**: High-throughput serialization (Protocol Buffers v3, FlatBuffers zero-copy parsing), gRPC over HTTP/2 & HTTP/3 multiplexing, connection pooling, request coalescing (Singleflight), and multi-tier caching.

---

## How to Use This Skill

- **Optimizing Code**: Apply the "Default Behaviors" checklist when refactoring or speeding up existing code. Always establish a benchmark baseline first.
- **Reviewing Code for Performance**: Use the "Optimization Review Rubric" to evaluate performance-oriented pull requests.
- **System & Build Configuration**: Reference compiler flags, PGO/AutoFDO pipelines, and CI/CD performance sections when setting up build pipelines or performance gating.
- **Deep-Dive Architecture**: Consult the corresponding file in `references/` when tackling specific domain challenges (e.g., GC tuning, zero-copy parsing, or GPU CUDA kernels).

---

## The Seven Pillars of Industrial Code Optimization

### 1. Measurement-First & Continuous Profiling
Optimization without measurement is speculation. High-performing engineering teams rely on continuous profiling and rigorous microbenchmarking.
- **Continuous Fleet Profiling**: Use non-intrusive sampling profilers (Google-Wide Profiling / GWP, Cloud Profiler, eBPF, Linux `perf` with PEBS and LBR) with <1% CPU overhead in production.
- **Microbenchmarking Frameworks**: Measure isolated routines using standard frameworks (Google Benchmark, JMH, Criterion, Pytest-benchmark).
- **Tail Latency Tracking**: Measure high percentiles (p90, p95, p99, p99.9 / TP999) rather than averages or medians.
- **Flamegraphs**: Utilize CPU and memory allocation flamegraphs to visualize call stacks and allocation hotspots.

### 2. Algorithmic Efficiency & CPU Cache Locality
Data structure choice and memory layout often have a far greater impact on execution speed than micro-level code tweaks.
- **Algorithmic Complexity**: Always evaluate Big-O time and space complexity first.
- **Cache Locality**: Sequential memory access patterns minimize CPU cache misses. Prefer contiguous data structures (dynamic vectors/arrays) over node-based structures (linked lists/trees).
- **Structure Layout (SoA vs AoS)**: Structure struct/class fields to minimize padding and false sharing. Use Structure of Arrays (SoA) over Array of Structures (AoS) for SIMD vectorization and memory bandwidth saturation.
- **Cache-Friendly Hash Tables**: Use flat open-addressing hash maps with SIMD control-byte probes (such as Abseil `absl::flat_hash_map`) instead of node-bucket maps (`std::unordered_map`).

### 3. Memory & Resource Management
Memory allocation and garbage collection (GC) pauses are major sources of latency variance in production systems.
- **Minimize Heap Allocations**: Reuse buffers, utilize stack allocations (`stackalloc`, `Span<T>`), and leverage arena/bump allocators for request-scoped lifespans.
- **Zero-Copy Architecture**: Avoid copying data when passing or parsing large buffers (use `std::string_view`, `std::span`, Rust borrowed slices, or FlatBuffers zero-copy access).
- **Efficient Binary Serialization**: Use Protocol Buffers or FlatBuffers instead of verbose text formats like JSON or XML.
- **Production Memory Allocators**: Deploy specialized allocators like Google's TCMalloc (Temeraire hugepage-aware allocator) or Meta's jemalloc to eliminate thread lock contention, reduce TLB stalls, and recover peak RAM.
- **GC Runtime Tuning**: In managed languages, configure soft memory limits (Go `GOMEMLIMIT`) or low-latency concurrent collectors (Java ZGC <1ms pauses) to eliminate STW latency spikes.

### 4. Concurrency, Parallelism & Hardware Acceleration
Leverage modern hardware capabilities safely and efficiently.
- **Lock Contention Reduction**: Prefer lock-free data structures (`std::atomic`, CAS operations, SPSC ring buffers) or fine-grained locking over coarse global mutexes.
- **Asynchronous High-Performance I/O**: Use thread pools for CPU-bound tasks and non-blocking ring-buffer I/O (Linux `io_uring`, `epoll`, async/await) for I/O-bound tasks.
- **Vectorization (SIMD)**: Structure loops for compiler auto-vectorization (AVX2, AVX-512, ARM NEON) or explicitly use SIMD intrinsics for data-parallel operations.
- **GPU Acceleration**: Offload massively parallel matrix and vector computations to GPUs via CUDA, Metal, or WebGPU, optimizing for memory coalescing, shared memory tiling, and warp divergence reduction.

### 5. Compiler & Build-Level Optimizations
Let the compiler and toolchain perform heavy optimizations automatically.
- **Profile-Guided Optimization (AutoFDO / PGO)**: Train compilers using production sampling profile data (`afdo.prof`) to optimize block layout, branch prediction, and inlining decisions.
- **Post-Link Binary Optimization**: Apply post-link tools like Meta's BOLT or Google's Propeller to reorder basic blocks and split hot/cold code sections at ELF binary level.
- **Link-Time Optimization (ThinLTO)**: Enable whole-program optimization across translation unit boundaries with parallel compilation scaling.
- **Compile-Time Evaluation**: Move runtime computations to compile time using `constexpr`, `consteval`, templates, or macros.

### 6. Network, I/O & Database Optimization
Network I/O is orders of magnitude slower than CPU operations.
- **Batching & Bulk Operations**: Group multiple network or database calls into single batch requests to eliminate $N+1$ query overhead.
- **Multiplexing & Connection Pooling**: Reuse persistent gRPC channels over HTTP/2 or HTTP/3, eliminating TCP 3-way handshake and TLS negotiation overhead.
- **Request Coalescing (Singleflight)**: Coalesce concurrent duplicate requests during cache misses to prevent cache stampedes (thundering herd).
- **Multi-Tier Caching**: Use multi-tier caching (L1 In-Memory -> L2 Distributed Redis/Memcached -> L3 Primary DB) with probabilistic early expiration (XFetch algorithm).

### 7. Production Performance Metrics & CI Gating
Ensure performance gains are maintained over time.
- **Automated Regression Testing**: Run automated microbenchmarks in CI pipelines on isolated runners to catch performance regressions (>2% threshold) before merging PRs.
- **Statistical Significance**: Apply non-parametric statistical tests (Mann-Whitney U test) across multiple benchmark runs to eliminate noise.
- **Key Industrial Metrics**: Track Queries Per Second per core (QPS/core), p99/p99.9 tail latencies, memory footprint per 1K connections, infrastructure cost per million operations ($/1M ops), and energy consumption per request.

---

## Industrial Performance Metrics Baseline

| Performance Dimension | Metric | Target Benchmark Baseline | Primary Tool |
| :--- | :--- | :--- | :--- |
| **Throughput** | QPS / Core | Maximized per server core | Load generators (k6, Locust, wrk2) |
| **Tail Latency** | p99 / p99.9 (TP999) | < SLO threshold (e.g., < 10ms) | OpenTelemetry, Prometheus, Datadog |
| **GC Pause Latency** | STW Pause Duration | < 1 ms (ZGC / Go tuned) | Runtime GC logs, `pprof` |
| **Memory Efficiency** | RSS / Request Overhead | Minimal heap allocation (0 in hot loops) | `pprof --alloc_objects`, TCMalloc stats |
| **Hardware Efficiency** | TLB & L1 Cache Misses | < 1% TLB misses, < 3% L1d misses | Linux `perf stat`, Intel VTune |
| **Financial / Cost** | $/1M Operations | Minimized infrastructure spend | Cloud billing & QPS cost model |

---

## Default Behaviors (Apply When Optimizing Code)

1. **Establish a Baseline**: Always run a microbenchmark and record baseline performance metrics (QPS, p99 latency, RAM allocations) before making any changes.
2. **Profile First**: Identify the specific hot path responsible for the bottleneck using continuous profiling or flamegraphs. Do not optimize code outside the hot path.
3. **Prioritize Readability and Safety**: Maintain clear code structure and type safety. Do not introduce unsafe or unreadable tricks for negligible gains.
4. **Optimize Big-O and Access Patterns First**: Focus on algorithmic efficiency, memory layout, and cache locality before micro-optimizations like loop unrolling.
5. **Verify Correctness with Tests**: Run the full test suite after optimizing to ensure no functional regressions or edge-case bugs were introduced.
6. **Re-Benchmark and Document**: Compare post-optimization benchmarks with the baseline. Document the reason for the change along with benchmark results in the commit or code comments.

---

## Optimization Review Rubric

When reviewing performance-focused code changes, verify:

1. **Evidence**: Is there benchmark or profiling data demonstrating that this change addresses a real bottleneck on the hot path?
2. **Correctness**: Does the optimized implementation maintain exact behavioral parity with the original code, including edge cases?
3. **Simplicity**: Is the performance gain significant (>3–5%) enough to justify any added code complexity?
4. **Safety & Concurrency**: Are thread safety, race conditions, memory bounds, and pointer/memory safety fully addressed?
5. **Portability**: Does the optimization rely on non-standard compiler extensions or target-specific instructions that break portability without fallback paths?

---

## Company Snapshots

- **Google**: Operates Google-Wide Profiling (GWP) across its fleet to continuously record CPU/memory stacks in production. Uses Profile-Guided Optimization (AutoFDO) and Propeller/ThinLTO across core services. Deploys TCMalloc with Temeraire hugepage-aware memory management. Optimized core libraries like Abseil provide cache-friendly containers (`absl::flat_hash_map`). Uses Protocol Buffers for fast binary serialization.
- **Meta**: Deploys BOLT post-link binary optimization to reorder ELF binary basic blocks. Focuses heavily on compiler and runtime optimizations for web and AI services (HHVM JIT compiler, PyTorch `torch.compile` JIT). Uses Thrift for binary RPC protocols, jemalloc for allocation, and runs automated regression benchmarking in CI.
- **Microsoft**: Emphasizes zero-allocation paradigms in modern C# and .NET (`Span<T>`, `Memory<T>`, `ArrayPool<T>`). Uses dynamic PGO extensively in C++ compilers, .NET 8/9 runtimes, and Windows kernel components. Uses mimalloc for high-throughput global allocations.
- **NVIDIA**: Optimizes for massive GPU parallelism via CUDA. Focuses on memory bandwidth saturation, shared memory tiling, warp divergence reduction, CUDA stream overlapping, and profiling via Nsight Systems.
- **Apple**: Prioritizes battery life and UI responsiveness. Uses Instruments for system-wide profiling, Swift ARC (Automatic Reference Counting) optimizations, copy-on-write (CoW) data structures, and hardware-accelerated frameworks like Metal and Accelerate.
