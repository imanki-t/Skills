# Continuous Profiling, AutoFDO, and Post-Link Binary Optimization

At warehouse-scale infrastructure (e.g., Google, Meta, Microsoft), static compiler optimizations (`-O3`) hit a ceiling because the compiler lacks runtime context. Industrial engineering organizations overcome this by deploying continuous fleet-wide profiling coupled with feedback-directed build pipelines.

---

## 1. Fleet-Wide Continuous Profiling Architecture

### Google-Wide Profiling (GWP) & Cloud Profiler
Continuous profiling continuously samples stack traces and CPU/memory counters across thousands of production instances with negligible overhead (<1% CPU/memory overhead).

- **Sampling Mechanism**:
  - Uses hardware PMUs (Performance Monitoring Units) via Linux `perf_events` or eBPF.
  - **PEBS (Precise Event-Based Sampling)**: Records instruction pointers and memory access addresses with minimal bias.
  - **LBR (Last Branch Record)**: Captures recent execution path history (branch source and target addresses) to reconstruct branch probabilities without instrumentation overhead.
- **Aggregation & Storage**:
  - Profiles are continuously streamed to a centralized analytics engine, aggregated across job clusters and release versions, and indexed by binary build ID / commit hash.
  - Generates representative workload profiles that reflect real production traffic patterns, including tail traffic and edge-case execution paths.

---

## 2. AutoFDO (Automatic Feedback-Directed Optimization)

Traditional Profile-Guided Optimization (PGO) required instrumented binary builds, which suffered from 2x–5x runtime slowdowns and required synthetic benchmark runs. **AutoFDO** replaces instrumentation with non-intrusive production sampling.

```
+-------------------+      +--------------------+      +--------------------+
| Production Fleet  | ---> | Linux perf / LBR   | ---> | AutoFDO Profile    |
| (Running Workload)|      | Sample Collection  |      | Conversion Tool    |
+-------------------+      +--------------------+      +--------------------+
                                                                 |
+-------------------+      +--------------------+                v
| Optimized Binary  | <--- | LLVM/GCC Compiler  | <--- [afdo.prof / profdata]
| Deployed to Fleet |      | Pass (-fprofile-   |
+-------------------+      | sample-use)        |
                           +--------------------+
```

### AutoFDO Toolchain Workflow

1. **Production Profile Collection**:
   ```bash
   # Collect hardware branch events using perf with LBR on production nodes
   perf record -e cycles:u -j any,u -a -o perf.data -- sleep 30
   ```
2. **Profile Conversion**:
   ```bash
   # Convert Linux perf.data to LLVM/GCC AutoFDO profile format
   create_llvm_prof --binary=/path/to/unstripped_binary \
                    --profile=perf.data \
                    --out=afdo.prof \
                    --format=binary
   ```
3. **Compiler Build Step**:
   ```bash
   # Apply profile data during LLVM compilation
   clang++ -O3 -fprofile-sample-use=afdo.prof -flto=thin main.cpp -o main_autofdo
   ```

### Compiler Optimization Transformations
When provided with AutoFDO profiles, compilers execute the following transformations:
- **Hot/Cold Block Separation**: Moves rarely executed error-handling code out of the main instruction stream to minimize L1 instruction cache (L1i) misses.
- **Intelligent Inlining**: Inlines functions based on actual execution frequency rather than static code size heuristics.
- **Branch Probability Alignment**: Layouts basic blocks so the hot branch path executes straight through without conditional jumps.
- **Indirect Call Promotion**: Converts virtual method calls or function pointers into conditional direct calls for the most frequent targets, enabling further inlining.

---

## 3. Post-Link Binary Optimizers: BOLT and Propeller

Standard compilers optimize code at the IR (Intermediate Representation) level before assembly layout. Post-link optimizers process fully linked ELF binaries to optimize machine code layout at basic-block granularity.

### Meta's BOLT (Binary Optimization and Layout Tool)
- Operates directly on linked binaries after Link-Time Optimization (LTO).
- Uses sample-based branch profiles to reorder functions, basic blocks, and cold code.
- **Impact**: Delivers 5%–15% additional performance improvements on top of PGO/AutoFDO by optimizing L1i cache utilization and I-TLB (Instruction Translation Lookaside Buffer) miss rates.
- **Command Sequence**:
  ```bash
  # Step 1: Collect perf data on PGO-compiled binary
  perf record -e cycles:u -j any,u -o perf.data -- ./service_binary
  
  # Step 2: Convert perf data to BOLT data format
  perf2bolt -p perf.data -o bolt.fdata ./service_binary
  
  # Step 3: Run BOLT binary transformation
  llvm-bolt ./service_binary -o ./service_binary.bolt \
            -data bolt.fdata \
            -reorder-blocks=ext-tsp \
            -reorder-functions=hfsort \
            -split-functions \
            -split-all-cold \
            -dyno-stats
  ```

### Google's Propeller
- Integrated directly into the LLVM linker (`lld`) ecosystem.
- Uses two-pass profile feedback: AutoFDO during compilation + Propeller basic block reordering at link time.
- Eliminates the need for post-link binary re-disassembly while matching BOLT's layout optimizations.

---

## 4. ThinLTO (Thin Link-Time Optimization)

Traditional LTO merges all compilation units into a single giant IR module, causing massive memory consumption and multi-hour build times for large codebases. **ThinLTO** solves this through distributed parallel optimization.

- **Mechanism**:
  1. Each compilation unit generates LLVM bitcode along with a concise **ThinLTO Summary Index**.
  2. The thin linker inspects the global index and determines cross-module inlining and dead-code elimination import graphs.
  3. Backend code generation executes in parallel across worker nodes, importing only the needed function IRs.
- **Build Configuration**:
  ```cmake
  # CMake ThinLTO Configuration
  set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -flto=thin")
  set(CMAKE_EXE_LINKER_FLAGS "${CMAKE_EXE_LINKER_FLAGS} -fuse-ld=lld -flto=thin")
  ```

---

## 5. Industrial Performance Impact & Operational Measures

| Optimization Pass | Typical Fleet CPU Gain | L1i Cache Miss Reduction | Primary Target Metric |
| :--- | :--- | :--- | :--- |
| Baseline (`-O3`) | Baseline (1.0x) | Baseline | - |
| AutoFDO / PGO | +8% to +15% | 20% - 35% | CPU Cycles per Request |
| ThinLTO | +3% to +6% | 10% - 15% | Binary Size & Cross-Module Inlining |
| BOLT / Propeller | +5% to +10% | 30% - 50% | I-TLB Stalls & Branch Mispredictions |
| **Combined Stack** | **+18% to +30%** | **50% - 70%** | **Fleetwide QPS / Core** |

### Automated CI/CD Feedback Pipeline
1. **Production Sampling**: Continuous profiler harvests 0.1% of fleet profiles daily.
2. **Profile Processing**: Automated pipeline validates profile coverage, strips machine-specific artifacts, and publishes standard `afdo.prof` artifacts to artifact storage.
3. **Weekly Build Pipeline**: Release builds pull the latest `afdo.prof`, compile with `-flto=thin -fprofile-sample-use`, apply Propeller/BOLT block reordering, and run canary integration tests before fleet rollout.
