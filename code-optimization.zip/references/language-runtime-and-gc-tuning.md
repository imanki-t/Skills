# Language Runtimes, Compiler Directives, and Garbage Collection Tuning

High-performance software engineering requires deep understanding of language-specific execution runtimes, memory management models, and garbage collection (GC) behavior.

---

## 1. C++ Optimization Best Practices

Modern C++ provides compile-time metaprogramming and zero-cost abstractions when used correctly.

### Move Semantics & RVO (Return Value Optimization)
- **Move Semantics (`std::move`)**: Transfers ownership of heap-allocated resources rather than performing deep memory copies.
- **RVO / NRVO (Named Return Value Optimization)**: Compilers construct returned objects directly in the memory space of the caller, bypassing move and copy constructors entirely.
- **Small String Optimization (SSO)**: C++ standard library strings store short character sequences (typically $\le 15$ or $22$ bytes depending on implementation) directly inside the string object on the stack, avoiding heap allocation.

### Compile-Time Evaluation (`constexpr` / `consteval`)
Shift execution overhead from runtime to compile time:
```cpp
// Evaluated entirely at compile time
constexpr uint64_t factorial(uint32_t n) {
    return (n <= 1) ? 1 : n * factorial(n - 1);
}
static_assert(factorial(5) == 120, "Compile-time validation");
```

---

## 2. Go Runtime & Memory Optimization

The Go runtime features a concurrent mark-and-sweep garbage collector, goroutine scheduler (M:N model), and escape analysis engine.

### Escape Analysis (`go build -gcflags="-m"`)
Go determines whether a variable can be allocated on the fast stack or must "escape" to the managed heap:
- Stack allocations are practically free ($O(1)$ pointer bump) and incur zero GC overhead.
- Heap allocations trigger GC pressure.

```go
// Stack Allocation (Fast, Zero GC)
func createPoint(x, y int) Point {
    return Point{X: x, Y: y} // Value returned directly on stack
}

// Heap Allocation (Escapes to Heap, Triggers GC)
func createPointPointer(x, y int) *Point {
    p := Point{X: x, Y: y}
    return &p // Pointer returned -> escapes to heap!
}
```

### Go GC Tuning: `GOMEMLIMIT` & `GOGC`
- **`GOMEMLIMIT` (Go 1.19+)**: Sets a soft memory limit for the Go runtime (e.g., `GOMEMLIMIT=3GiB`). Prevents OOM container crashes while allowing the GC to delay sweep cycles when memory headroom is available.
- **`GOGC`**: Controls GC trigger frequency relative to heap growth (default = 100). Setting `GOGC=off` in short-lived jobs or tuning `GOGC` dynamically reduces CPU overhead spent in GC mark phases.
- **`sync.Pool`**: Reuses temporary allocated objects across goroutines to eliminate GC allocation pressure in hot RPC handlers.

---

## 3. Java & JVM Runtime Optimization

The Java Virtual Machine (JVM) relies on Just-In-Time (JIT) compilers (C1, C2) and advanced multi-generational garbage collectors.

### Ultra-Low Latency Garbage Collectors: ZGC & Shenandoah
- **ZGC (Z Garbage Collector)**: Concurrent, low-latency garbage collector designed for heaps ranging from megabytes to multiple terabytes.
  - Keeps STW (Stop-The-World) GC pause times **< 1 millisecond** regardless of heap size!
  - Uses colored pointers and load barriers to perform concurrent marking and compaction.
- **Enable ZGC in JVM Arguments**:
  ```bash
  java -XX:+UseZGC -XX:+ZGenerational -Xms8g -Xmx8g -jar service.jar
  ```

### JVM Performance Flags
- **`-XX:+UseStringDeduplication`**: Deduplicates identical String character arrays in memory, reducing JVM heap footprints by 10%–20%.
- **GraalVM Native Image**: Ahead-Of-Time (AOT) compiles Java bytecode directly into native ELF binaries, reducing startup time from seconds to milliseconds and cutting memory footprints by 50%+.

---

## 4. Rust Zero-Cost Abstractions & Allocators

Rust enforces memory safety at compile time through ownership and borrowing semantics without runtime GC overhead.

### Inline Directives & LTO
- **`#[inline(always)]`**: Forces compiler to inline small critical functions across crate boundaries.
- **`#[inline(never)]`**: Prevents inlining on cold error-handling functions to keep hot instruction loops compact.

### Custom Global Allocators
In multi-threaded high-throughput Rust services, replacing the default system allocator with `jemalloc` or `mimalloc` significantly reduces thread lock contention:

```rust
// Replace default allocator with jemalloc in Rust
use jemallocator::Jemalloc;

#[global_allocator]
static GLOBAL: Jemalloc = Jemalloc;
```

---

## 5. Python & Dynamic Language Acceleration

Standard CPython is constrained by interpreted bytecode overhead and the GIL (Global Interpreter Lock).

### Industrial Python Optimization Hierarchy
1. **Vectorization**: Replace raw Python loops with vector operations in `NumPy` or `Polars` (executed via SIMD C/C++ backends).
2. **`torch.compile` & PyTorch JIT**: Compiles Python deep learning operations into optimized CUDA/C++ kernels via TorchDynamo and Inductor.
3. **C-Extensions & Cython**: Compile hot algorithmic inner loops into native C/C++ extensions.

```python
# Unoptimized Python Loop (Slow)
total = 0.0
for x in data_list:
    total += x * 2.5

# Optimized Vectorized NumPy (100x Faster)
import numpy as np
data_arr = np.array(data_list, dtype=np.float64)
total = np.dot(data_arr, 2.5)
```

---

## 6. Language Optimization Reference Summary

| Language | Primary Bottleneck | Optimization Lever | Peak Metric Impact |
| :--- | :--- | :--- | :--- |
| **C++** | Heap Alloc & Copies | `std::string_view`, Move, Custom Allocator | 2x - 5x Speedup |
| **Go** | GC Pauses & Heap Escape | `GOMEMLIMIT`, `sync.Pool`, Value Receivers | 30% - 50% Lower Latency |
| **Java** | STW GC Latency Spikes | ZGC (`-XX:+UseZGC`), String Deduplication | < 1ms STW Pauses |
| **Rust** | Default Allocator Contention | `jemalloc`, `Bumpalo` Arena, LTO | 20% - 40% Throughput Gain |
| **Python**| Bytecode Loop Interpreter | `NumPy` Vectorization, `torch.compile`, C-Ext | 10x - 100x Speedup |
