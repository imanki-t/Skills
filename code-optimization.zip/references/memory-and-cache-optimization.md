# Memory Alignment, Cache Locality, and Production Allocators

Memory access latencies dominate modern computing performance. CPU L1 cache access takes ~1 ns (4 clock cycles), while main memory (DRAM) access takes ~100 ns (200-300 clock cycles). High-throughput production services must treat memory layout and allocation as primary optimization vectors.

---

## 1. CPU Cache Hierarchy & Locality Principles

### Cache Line Dynamics
Modern x86 and ARM CPUs transfer data between DRAM and CPU caches in fixed 64-byte blocks called **cache lines**.

- **Spatial Locality**: Accessing memory location $N$ brings locations $N+1 \dots N+63$ into the cache line automatically. Sequential data structures (arrays/vectors) maximize spatial locality.
- **Temporal Locality**: Reusing recently accessed memory before it is evicted from the L1/L2 cache.
- **False Sharing**: Occurs when two distinct threads on separate CPU cores modify adjacent independent variables residing within the same 64-byte cache line, triggering expensive cache-invalidation ping-ponging across core interconnects.
  ```cpp
  // Incorrect: False sharing hazard
  struct ThreadCounters {
      uint64_t thread1_count; // Core 0 modifies this
      uint64_t thread2_count; // Core 1 modifies this (same 64B cache line!)
  };

  // Correct: Cache line alignment (C++17)
  struct alignas(64) ThreadCountersAligned {
      uint64_t thread1_count;
  }; // Guaranteed separate 64-byte line
  ```

---

## 2. Structure Layouts: SoA vs. AoS

### Array of Structures (AoS) vs. Structure of Arrays (SoA)
- **AoS (Standard Object-Oriented Layout)**: Interleaves attributes together in memory (`[XYZW, XYZW, XYZW]`). Excellent for accessing all fields of a single object, but inefficient for vector operations.
- **SoA (SIMD / Cache-Optimized Layout)**: Groups contiguous arrays for each field (`[X,X,X], [Y,Y,Y], [Z,Z,Z]`). Saturates memory bandwidth and enables 100% vectorization in SIMD loops.

```cpp
// AoS Layout (Cache Unfriendly for Batch Operations)
struct ParticleAoS {
    float x, y, z;
    float vx, vy, vz;
    uint32_t id;
    char name[32]; // Padding & heavy bloat
};
// Processing position 'x' fetches unwanted name/id bytes into L1 cache.

// SoA Layout (Cache & SIMD Friendly)
struct ParticleSoA {
    std::vector<float> x;
    std::vector<float> y;
    std::vector<float> z;
    std::vector<float> vx;
    std::vector<float> vy;
    std::vector<float> vz;
};
// Updating 'x' reads purely 32-bit floats sequentially: 16 floats per 64-byte cache line!
```

---

## 3. Cache-Friendly Hash Tables: Abseil Swiss Tables (`absl::flat_hash_map`)

Standard C++ `std::unordered_map` relies on chained node bucketing (`std::list` of nodes), resulting in 1 pointer indirection per lookup and high heap fragmentation.

Google's Abseil Swiss Tables (`absl::flat_hash_map`) replace node chaining with **flat open addressing** and **SIMD control byte probing**:

1. **Control Byte Array**: Stores 1-byte hash metadata (H1 7-bit fingerprint) for 16 slots per group.
2. **SIMD Probe**: Uses SSE2/AVX2 or NEON instructions (`_mm_cmpeq_epi8`) to search 16 bucket control bytes in a single instruction.
3. **Contiguous Slots**: Stores key-value pairs inline in a single flat array.
4. **Efficiency Gain**: Replaces 2–3 memory pointer hops with 1 memory fetch and a 1-cycle SIMD comparison, delivering 2x–3x faster lookups and 50% lower memory usage.

---

## 4. Production Memory Allocators: TCMalloc, jemalloc, mimalloc

The default system allocator (`glibc malloc`) suffers from lock contention under multi-threaded workloads and high fragmentation over extended runtimes. Industrial systems use specialized allocators.

### Google's TCMalloc & Temeraire (Hugepage-Aware Allocator)
- **Thread-Cache Architecture**: Assigns small allocation pools (<256 KB) per thread or per CPU (rseq - restartable sequences) to perform $O(1)$ allocations with zero lock acquisition.
- **Central Free List**: Handles larger allocation requests using lock-free page heaps.
- **Temeraire (Hugepage-Aware Allocator - OSDI 2021)**:
  - Manages memory at 2 MB hugepage boundaries directly in user-space.
  - Reduces Translation Lookaside Buffer (TLB) misses across fleet workloads by up to **6%–8%**.
  - Reduces memory fragmentation by **26%** and recovers peak fleet RAM by **2.4%** while increasing QPS by **3%–7%**.

### Meta's jemalloc & Microsoft's mimalloc
- **jemalloc**: Focuses on fragmentation reduction via size classing and arena management.
- **mimalloc**: Uses free-list sharding and thread-local heap pages for high performance in parallel workloads.

---

## 5. Zero-Copy & Zero-Allocation Engineering

Heap allocation in hot execution loops creates GC pauses in managed languages and memory fragmentation in C/C++. High-performance systems use zero-copy views and stack/arena strategies.

### Modern Language Zero-Copy Types

| Language | Type | Description |
| :--- | :--- | :--- |
| **C++** | `std::string_view`, `std::span` | Non-owning references to contiguous character/object buffers. Eliminates string copies. |
| **C# / .NET** | `Span<T>`, `ReadOnlySpan<T>`, `Memory<T>` | Stack-allocated representation of contiguous arbitrary memory (array, stackalloc, native buffer). |
| **Rust** | `&str`, `&[T]` | Borrowed slices with compile-time lifetime safety guarantees. |
| **Go** | `[]byte`, string slicing | Sub-slice referencing without underlying array reallocation. |

### Arena / Bump Allocation Pattern
For request-scoped or frame-scoped processing, allocating individual objects on the heap is wasteful. An **Arena Allocator** pre-allocates a large buffer and fulfills requests by incrementing an offset pointer ("bumping" the pointer).

```cpp
class ArenaAllocator {
    uint8_t* buffer_;
    size_t capacity_;
    size_t offset_ = 0;

public:
    ArenaAllocator(size_t capacity) : capacity_(capacity) {
        buffer_ = static_cast<uint8_t*>(std::malloc(capacity));
    }
    ~ArenaAllocator() { std::free(buffer_); }

    void* allocate(size_t bytes, size_t alignment = 8) {
        size_t aligned_offset = (offset_ + alignment - 1) & ~(alignment - 1);
        if (aligned_offset + bytes > capacity_) throw std::bad_alloc();
        offset_ = aligned_offset + bytes;
        return buffer_ + aligned_offset;
    }

    // Reset entire arena in 1 CPU cycle
    void reset() { offset_ = 0; }
};
```

---

## 6. Industrial Memory Metrics & Benchmarks

| Metric | Measurement Tool / Command | Industrial Target Baseline |
| :--- | :--- | :--- |
| **Allocations / Request** | Custom profiler, `pprof --alloc_objects` | **0** in core hot processing paths |
| **TLB Miss Rate** | `perf stat -e dTLB-load-misses` | < 1% of total memory accesses |
| **L1d Cache Miss Rate** | `perf stat -e L1-dcache-load-misses` | < 3% of total data accesses |
| **Peak Resident Memory (RSS)** | `/proc/self/status` (`VmHWM`) | Within budgeted container CGroup limits |
| **Fragmentation Ratio** | Allocator internal metrics (`TCMalloc` stats) | < 15% wasted overhead |
