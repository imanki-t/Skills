# Network I/O, Serialization Protocols, and Caching Architectures

In distributed systems, Network I/O and data serialization dominate latency profiles. A single cross-datacenter network round-trip (~1–5 ms) takes millions of CPU cycles. Optimizing transport efficiency, serialization overhead, and caching layers yields massive infrastructure QPS gains.

---

## 1. High-Performance Serialization Protocols

Verbose text serialization formats (JSON, XML) suffer from high CPU parsing overhead (string parsing, number formatting, float conversions) and large wire sizes. Binary serialization protocols eliminate this bottleneck.

```
+-------------------------------------------------------------------------------+
|                       SERIALIZATION EFFICIENCY MATRIX                         |
+-------------------+-----------------+-------------------+---------------------+
| Format            | Parsing Speed   | Allocations/Read  | Schema Requirement  |
+-------------------+-----------------+-------------------+---------------------+
| JSON              | Slow (Text)     | High (Objects)    | No Schema           |
| Protocol Buffers  | Fast (Binary)   | Low               | Compiled .proto     |
| FlatBuffers       | Instant (0-Copy)| ZERO              | Compiled FlatSchema |
| Cap'n Proto       | Instant (0-Copy)| ZERO              | Compiled CapnSchema |
+-------------------+-----------------+-------------------+---------------------+
```

### Protocol Buffers (Protobuf v3)
- Uses varint encoding for integers and compact field tag identifiers.
- Replaces field name strings with integer field tags (e.g., field 1 = `id`), reducing payload sizes by 60%–80% compared to JSON.

### FlatBuffers & Cap'n Proto (Zero-Copy Access)
- **FlatBuffers** formats hierarchical data in a flat binary memory buffer using offset tables.
- **Zero-Allocation Reading**: Allows applications to access serialized data directly from mapped memory buffers **without unpacking or allocating objects**:
  ```cpp
  // Reading FlatBuffers without allocation or parsing overhead!
  auto monster = GetMonster(buffer_pointer);
  int hp = monster->hp(); // Direct offset pointer lookup: O(1) time, 0 allocations!
  ```

---

## 2. Network & RPC Optimization (gRPC, HTTP/2, HTTP/3)

### HTTP/2 & HTTP/3 Multiplexing
- **gRPC**: Built on HTTP/2 (and HTTP/3 QUIC transport). Multiplexes thousands of concurrent RPC requests over a single persistent TCP connection.
- **Header Compression**: Uses HPACK (HTTP/2) and QPACK (HTTP/3) to compress repetitive HTTP headers across requests.

### Connection Pooling & Keepalives
Re-establishing TCP connections and performing TLS 1.3 handshakes adds **50–150 ms** of latency per connection setup.
- **Connection Reuse**: Maintain persistent connection pools for backend microservices.
- **TCP Keepalives & Probing**: Configure TCP keepalives to detect dead sockets promptly while avoiding unexpected connection drops during idle periods.

```
Unoptimized: New TLS Connection Per Request
[Client] --- TCP Syn / TLS Handshake (50-150ms) ---> [Server] ---> [Process] ---> [Close]

Optimized: Persistent Connection Pool (Zero Setup Overhead)
[Client] ================= Persistent gRPC Pool =================> [Server]
         --- Request 1 (Direct Stream) --->
         --- Request 2 (Multiplexed) ------>
```

---

## 3. I/O Batching & Request Coalescing

### Eliminating N+1 Request Bottlenecks
Issuing individual RPC or database requests in a loop ($N+1$ query hazard) multiplies network latency by $N$.

```
// N+1 Query Anti-Pattern (Slow: N Network Round Trips)
for (const auto& user_id : user_ids) {
    user_data.push_back(fetch_user_rpc(user_id)); // N latency penalties!
}

// Batch Request Pattern (Fast: 1 Network Round Trip)
auto batch_user_data = fetch_users_batch_rpc(user_ids); // Single bulk call
```

### Request Coalescing (Singleflight Pattern)
When thousands of concurrent requests query the exact same missing cache key simultaneously (Cache Stampede / Thundering Herd), **Singleflight** coalesces all concurrent calls into a single downstream execution, sharing the response across all waiting callers.

---

## 4. Multi-Tier Caching Architecture

To achieve sub-millisecond response times, distributed architectures organize caching into multi-tier hierarchies:

```
[User Request]
      |
      v
[ L1: Local In-Memory Cache (Abseil / Ristretto / Caffeine) ]  <-- Latency: ~10 ns
      | (Cache Miss)
      v
[ L2: Distributed Cache (Redis / Memcached Cluster) ]         <-- Latency: ~1-2 ms
      | (Cache Miss)
      v
[ L3: Primary Database (PostgreSQL / Spanner) ]                <-- Latency: ~10-50 ms
```

### Cache Invalidation & Protection Strategies
- **Cache-Aside (Lazy Loading)**: Application reads from cache. On miss, reads from DB, writes to cache, and returns response.
- **Probabilistic Early Expiration (XFetch Algorithm)**: Automatically refreshes cache keys before they expire based on access frequency and remaining TTL, completely preventing cache stampedes.

---

## 5. Network & I/O Metrics Baseline

| Metric | Measurement Strategy | Production Industrial Target |
| :--- | :--- | :--- |
| **Serialization Throughput** | Microbenchmark (GB/sec) | > 2 GB/s per core |
| **RPC Round-Trip Time (RTT)**| Distributed Tracing (OpenTelemetry) | < 2 ms inside same region |
| **TCP Connection Reuse** | Socket metrics (`netstat` / `ss`) | > 99% request reuse on pooled connections |
| **L1 Cache Hit Ratio** | Application metrics / Prometheus | > 90% hit rate for hot keys |
